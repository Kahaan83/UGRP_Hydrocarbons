# Flash point — physics baseline (Le Chatelier + Raoult + Antoine)

Records: 915   predicted: 147   not predictable: 768   LFL(T) correction: False

Why records could not be predicted:
| status | n |
|---|---|
| missing antoine_A,antoine_B,antoine_C | 439 |
| missing antoine_A,antoine_B,antoine_C,lfl_vol_pct | 329 |

## Overall
| index | value |
|---|---|
| n | 147 |
| MAE | 7.28 |
| RMSE | 15.31 |
| bias | 2.67 |
| median_abs | 2.39 |
| over_pred_pct | 40.14 |
| over_by_5C_pct | 17.01 |
| within_5C_pct | 70.75 |

## by kind (pure / binary / multi)
| kind | n | MAE | RMSE | bias | median_abs | over_pred_pct | over_by_5C_pct | within_5C_pct |
|---|---|---|---|---|---|---|---|---|
| binary | 54 | 1.59 | 1.86 | -1.27 | 1.67 | 11.11 | 0 | 98.15 |
| multi | 3 | 2.89 | 2.92 | -2.89 | 2.86 | 0 | 0 | 100 |
| pure | 90 | 10.84 | 19.5 | 5.23 | 4.49 | 58.89 | 27.78 | 53.33 |

## Antoine valid at the predicted T?
| antoine_in_range | n | MAE | RMSE | bias | median_abs | over_pred_pct | over_by_5C_pct | within_5C_pct |
|---|---|---|---|---|---|---|---|---|
| False | 66 | 5.33 | 13.12 | 0.37 | 2.07 | 27.27 | 9.09 | 80.3 |
| True | 81 | 8.87 | 16.88 | 4.55 | 3.02 | 50.62 | 23.46 | 62.96 |

## LFL all measured (True) or any estimated (False)
| lfl_all_measured | n | MAE | RMSE | bias | median_abs | over_pred_pct | over_by_5C_pct | within_5C_pct |
|---|---|---|---|---|---|---|---|---|
| False | 95 | 10.06 | 18.87 | 4.59 | 3.15 | 46.32 | 24.21 | 58.95 |
| True | 52 | 2.22 | 3.39 | -0.83 | 1.64 | 28.85 | 3.85 | 92.31 |

## aromatic present
| has_aromatic | n | MAE | RMSE | bias | median_abs | over_pred_pct | over_by_5C_pct | within_5C_pct |
|---|---|---|---|---|---|---|---|---|
| False | 73 | 6.43 | 14.34 | 0.78 | 2.39 | 35.62 | 10.96 | 73.97 |
| True | 74 | 8.12 | 16.21 | 4.54 | 2.38 | 44.59 | 22.97 | 67.57 |

## by heaviest component (carbon number)
| max_C_bin | n | MAE | RMSE | bias | median_abs | over_pred_pct | over_by_5C_pct | within_5C_pct |
|---|---|---|---|---|---|---|---|---|
| <=C5 | 3 | 5.76 | 8.27 | -5.76 | 2.84 | 0 | 0 | 66.67 |
| C6-8 | 72 | 2.08 | 3.18 | -1.49 | 1.71 | 18.06 | 0 | 95.83 |
| C9-12 | 27 | 2.86 | 3.68 | 0.27 | 2.41 | 59.26 | 7.41 | 81.48 |
| C13-16 | 24 | 14.9 | 23.78 | 9.39 | 9.69 | 62.5 | 45.83 | 29.17 |
| >C16 | 21 | 22.31 | 30.53 | 13.57 | 16.26 | 71.43 | 57.14 | 19.05 |

## by class composition
| classes | n | MAE | RMSE | bias | median_abs | over_pred_pct | over_by_5C_pct | within_5C_pct |
|---|---|---|---|---|---|---|---|---|
| n_paraffin | 46 | 7.75 | 17.47 | 1.99 | 2.24 | 26.09 | 15.22 | 73.91 |
| aromatic | 43 | 12.78 | 21.2 | 8.61 | 6.98 | 62.79 | 39.53 | 44.19 |
| aromatic+n_paraffin | 31 | 1.66 | 1.83 | -1.1 | 1.69 | 19.35 | 0 | 100 |
| alkene_alkyne | 17 | 4.44 | 6.72 | -2.02 | 2.77 | 52.94 | 0 | 82.35 |
| cycloalkane | 5 | 4.01 | 5.01 | 0.87 | 2.92 | 60 | 20 | 60 |
| iso_paraffin | 4 | 3.11 | 3.71 | 0.16 | 3.27 | 50 | 0 | 75 |
| iso_paraffin+n_paraffin | 1 | 5 | 5 | -5 | 5 | 0 | 0 | 0 |

## worst 15 records (largest |error|)
| kind | n_comp | classes | max_n_carbon | measured_C | predicted_C | err_C | antoine_in_range | lfl_all_measured | conflict |
|---|---|---|---|---|---|---|---|---|---|
| pure | 1 | n_paraffin | 25 | 120 | 212.5 | 92.5 | True | False | False |
| pure | 1 | aromatic | 16 | 103.5 | 194.8 | 91.3 | False | False | True |
| pure | 1 | aromatic | 19 | 160.3 | 220.3 | 60 | True | False | False |
| pure | 1 | aromatic | 14 | 121 | 162.9 | 41.9 | True | False | True |
| pure | 1 | n_paraffin | 22 | 149 | 188.1 | 39.1 | True | False | True |
| pure | 1 | n_paraffin | 21 | 145 | 178.6 | 33.6 | True | False | True |
| pure | 1 | n_paraffin | 24 | 234.5 | 204.6 | -29.9 | True | False | False |
| pure | 1 | n_paraffin | 23 | 167.9 | 196.1 | 28.2 | True | False | True |
| pure | 1 | aromatic | 20 | 228.6 | 253.9 | 25.3 | True | False | False |
| pure | 1 | aromatic | 16 | 168.8 | 193.3 | 24.5 | True | False | False |
| pure | 1 | aromatic | 16 | 107 | 131.3 | 24.3 | False | False | False |
| pure | 1 | aromatic | 20 | 228.6 | 251.3 | 22.7 | False | False | False |
| pure | 1 | aromatic | 15 | 157.5 | 178.1 | 20.6 | True | False | False |
| pure | 1 | alkene_alkyne | 6 | -27.1 | -46.7 | -19.6 | False | False | False |
| pure | 1 | aromatic | 20 | 228.6 | 247.2 | 18.6 | True | False | False |

## Does the ideal-mixing assumption hold? (mixtures only)
mixtures predicted: 57;  MAE 1.7 C;  mean err -1.4 C.  Compare with the pure-compound MAE above: a clearly larger mixture error means non-ideality (gamma != 1) is the thing to learn.