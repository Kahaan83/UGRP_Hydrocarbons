# Unified dataset report

## Sources loaded
- leenhouts:flashpoint_pure_exp.csv: 585 rows
- leenhouts:flashpoint_mix_exp.csv: 1006 rows
- leenhouts:viscosity_pure_exp.csv: 3027 rows
- leenhouts:viscosity_mix_exp.csv: 35938 rows
- leenhouts:dcn_pure_exp.csv: 229 rows
- leenhouts:dcn_mix_exp.csv: 484 rows
- leenhouts:mon_pure_exp.csv: 332 rows
- leenhouts:mon_mix_exp.csv: 292 rows
- nist_tde: 15779 rows
- thermoml: 46747 rows
- ajftd: 30821 rows
- flashpoint_li: 14696 rows
- fortin2012: 252 rows
- crc: 5431 rows
- chew2024: 3582 rows
- saldana11: 631 rows
- pure_freezing: 27 rows

Rows before dedupe: 101710   after: 76175   conflicts (sources disagree): 1199
Unparsed structures: 0   compounds in registry: 1038 (hydrocarbons: 1038)

## Hydrocarbon-only usable observations (after dedupe)

| property | binary | multi | pure | real_fuel |
|---|---|---|---|---|
| acid_number_mg_koh_g | 0 | 0 | 0 | 53 |
| aromatics_vol_pct | 0 | 0 | 0 | 77 |
| benzothiophenes_ppm_wt | 0 | 0 | 0 | 57 |
| cloud_point_C | 0 | 0 | 0 | 3 |
| conductivity_ps_m | 0 | 0 | 0 | 171 |
| d86_residue_pct | 0 | 0 | 0 | 57 |
| dcn | 213 | 133 | 80 | 0 |
| density_kg_m3 | 12747 | 897 | 1752 | 3056 |
| dibenzothiophenes_ppm_wt | 0 | 0 | 0 | 57 |
| dielectric_constant | 0 | 0 | 0 | 340 |
| distillation_T0.025_C | 0 | 0 | 0 | 12 |
| distillation_T0_C | 0 | 0 | 0 | 1760 |
| distillation_T100_C | 0 | 0 | 0 | 2239 |
| distillation_T10_C | 0 | 0 | 0 | 2252 |
| distillation_T15_C | 0 | 0 | 0 | 33 |
| distillation_T20_C | 0 | 0 | 0 | 707 |
| distillation_T25_C | 0 | 0 | 0 | 33 |
| distillation_T30_C | 0 | 0 | 0 | 94 |
| distillation_T35_C | 0 | 0 | 0 | 33 |
| distillation_T40_C | 0 | 0 | 0 | 94 |
| distillation_T45_C | 0 | 0 | 0 | 33 |
| distillation_T50_C | 0 | 0 | 0 | 2254 |
| distillation_T55_C | 0 | 0 | 0 | 33 |
| distillation_T5_C | 0 | 0 | 0 | 264 |
| distillation_T60_C | 0 | 0 | 0 | 94 |
| distillation_T65_C | 0 | 0 | 0 | 33 |
| distillation_T70_C | 0 | 0 | 0 | 94 |
| distillation_T75_C | 0 | 0 | 0 | 33 |
| distillation_T80_C | 0 | 0 | 0 | 94 |
| distillation_T85_C | 0 | 0 | 0 | 34 |
| distillation_T90_C | 0 | 0 | 0 | 2239 |
| distillation_T95_C | 0 | 0 | 0 | 250 |
| distillation_loss_pct | 0 | 0 | 0 | 2504 |
| distillation_recovery_pct | 0 | 0 | 0 | 804 |
| distillation_residue_pct | 0 | 0 | 0 | 2512 |
| flash_point_C | 123 | 3 | 789 | 2349 |
| freezing_point_C | 0 | 0 | 25 | 2278 |
| gas_solubility_air_ppm_wt | 0 | 0 | 0 | 18 |
| gas_solubility_ar_ppm_wt | 0 | 0 | 0 | 18 |
| gas_solubility_n2_ppm_wt | 0 | 0 | 0 | 18 |
| gas_solubility_o2_ppm_wt | 0 | 0 | 0 | 18 |
| hydrogen_wt_pct | 0 | 0 | 0 | 57 |
| lubricity_wear_scar_mm | 0 | 0 | 0 | 57 |
| mon | 30 | 76 | 267 | 0 |
| naphthalenes_vol_pct | 0 | 0 | 0 | 57 |
| net_heat_content_btu_lb | 0 | 0 | 0 | 57 |
| net_heat_content_calculated_method_btu_lb | 0 | 0 | 0 | 57 |
| nitrogen_solubility_ppm_wt | 0 | 0 | 0 | 19 |
| olefins_vol_pct | 0 | 0 | 0 | 57 |
| polar_species_final_0.6min_elution_mg_l | 0 | 0 | 0 | 19 |
| polar_species_total_mg_l | 0 | 0 | 0 | 20 |
| pour_point_C | 0 | 0 | 0 | 60 |
| refractive_index | 0 | 0 | 0 | 57 |
| saturates_vol_pct | 0 | 0 | 0 | 57 |
| smoke_point_mm | 0 | 0 | 0 | 2197 |
| specific_heat_capacity_j_g_k | 0 | 0 | 0 | 50 |
| specific_heat_capacity_slope | 0 | 0 | 0 | 50 |
| speed_of_sound_m_s | 0 | 0 | 0 | 170 |
| sulfur_mercaptan_wt_ppm | 0 | 0 | 0 | 57 |
| sulfur_total_by_hplc_class_ppm_wt | 0 | 0 | 0 | 57 |
| sulfur_wt_ppm | 0 | 0 | 0 | 57 |
| surface_tension_mn_m | 0 | 0 | 0 | 135 |
| thermal_stability_break_point_C | 0 | 0 | 0 | 53 |
| thermal_stability_spent_fuel_mL | 0 | 0 | 0 | 176 |
| thiols_sulfides_disulfides_ppm_wt | 0 | 0 | 0 | 57 |
| thiophenes_ppm_wt | 0 | 0 | 0 | 57 |
| vapor_pressure_d2879_kpa | 0 | 0 | 0 | 76 |
| vapor_pressure_d6378_kpa | 0 | 0 | 0 | 76 |
| vapor_pressure_kPa | 2021 | 64 | 4415 | 0 |
| viscosity_dyn_mPas | 16037 | 625 | 2270 | 0 |
| viscosity_kin_cSt | 28 | 0 | 67 | 2569 |

## Ranges

| property | n | vmin | vmax | Tmin | Tmax | systems |
|---|---|---|---|---|---|---|
| acid_number_mg_koh_g | 53 | 0 | 0.019 | nan | nan | 53 |
| aromatics_vol_pct | 77 | 0 | 23.09 | nan | nan | 77 |
| benzothiophenes_ppm_wt | 57 | 0 | 536 | nan | nan | 57 |
| cloud_point_C | 3 | -23 | -10 | nan | nan | 3 |
| conductivity_ps_m | 171 | 0 | 355 | 278.8 | 310.9 | 57 |
| d86_residue_pct | 57 | 1.2 | 2.1 | nan | nan | 57 |
| dcn | 426 | 2.8 | 104.4 | nan | nan | 118 |
| density_kg_m3 | 18452 | 0.81 | 1083 | -40 | 468.5 | 2663 |
| dibenzothiophenes_ppm_wt | 57 | 0 | 370 | nan | nan | 57 |
| dielectric_constant | 340 | 1.996 | 2.251 | 233.8 | 344.1 | 57 |
| distillation_T0.025_C | 12 | 202.6 | 213.8 | nan | nan | 12 |
| distillation_T0_C | 1760 | -29 | 367 | nan | nan | 1760 |
| distillation_T100_C | 2239 | 89 | 507 | nan | nan | 2239 |
| distillation_T10_C | 2252 | -3 | 387 | nan | nan | 2252 |
| distillation_T15_C | 33 | 72 | 252 | nan | nan | 33 |
| distillation_T20_C | 707 | 66 | 337 | nan | nan | 707 |
| distillation_T25_C | 33 | 93 | 252 | nan | nan | 33 |
| distillation_T30_C | 94 | 93 | 253 | nan | nan | 94 |
| distillation_T35_C | 33 | 93 | 253 | nan | nan | 33 |
| distillation_T40_C | 94 | 93 | 253 | nan | nan | 94 |
| distillation_T45_C | 33 | 93 | 253 | nan | nan | 33 |
| distillation_T50_C | 2254 | 67 | 420 | nan | nan | 2254 |
| distillation_T55_C | 33 | 106 | 253 | nan | nan | 33 |
| distillation_T5_C | 264 | -5 | 252 | nan | nan | 264 |
| distillation_T60_C | 94 | 111 | 259 | nan | nan | 94 |
| distillation_T65_C | 33 | 113 | 272 | nan | nan | 33 |
| distillation_T70_C | 94 | 113 | 278 | nan | nan | 94 |
| distillation_T75_C | 33 | 116 | 282 | nan | nan | 33 |
| distillation_T80_C | 94 | 116 | 286 | nan | nan | 94 |
| distillation_T85_C | 34 | 116 | 289 | nan | nan | 34 |
| distillation_T90_C | 2239 | 40.3 | 472 | nan | nan | 2239 |
| distillation_T95_C | 250 | 121 | 314.6 | nan | nan | 250 |
| distillation_loss_pct | 2504 | 0 | 97.7 | nan | nan | 2504 |
| distillation_recovery_pct | 804 | 97.1 | 99.6 | nan | nan | 804 |
| distillation_residue_pct | 2512 | 0 | 3.5 | nan | nan | 2512 |
| flash_point_C | 3264 | -88 | 247.2 | nan | nan | 3169 |
| freezing_point_C | 2303 | -126.5 | 80.05 | nan | nan | 2303 |
| gas_solubility_air_ppm_wt | 18 | 197.9 | 387.3 | 293.1 | 293.1 | 18 |
| gas_solubility_ar_ppm_wt | 18 | 4.5 | 7.7 | 293.1 | 293.1 | 18 |
| gas_solubility_n2_ppm_wt | 18 | 122.4 | 257.8 | 293.1 | 293.1 | 18 |
| gas_solubility_o2_ppm_wt | 18 | 71 | 121.8 | 293.1 | 293.1 | 18 |
| hydrogen_wt_pct | 57 | 13.71 | 15.28 | nan | nan | 57 |
| lubricity_wear_scar_mm | 57 | 0.54 | 0.74 | nan | nan | 57 |
| mon | 373 | -2 | 120 | nan | nan | 289 |
| naphthalenes_vol_pct | 57 | 0 | 3.8 | nan | nan | 57 |
| net_heat_content_btu_lb | 57 | 1.833e+04 | 1.878e+04 | nan | nan | 57 |
| net_heat_content_calculated_method_btu_lb | 57 | 1.848e+04 | 1.881e+04 | nan | nan | 57 |
| nitrogen_solubility_ppm_wt | 19 | 172.3 | 416 | 293.1 | 293.1 | 19 |
| olefins_vol_pct | 57 | 0.417 | 4.25 | nan | nan | 57 |
| polar_species_final_0.6min_elution_mg_l | 19 | 9.7 | 233.1 | nan | nan | 19 |
| polar_species_total_mg_l | 20 | 80.1 | 1044 | nan | nan | 20 |
| pour_point_C | 60 | -80 | -30 | nan | nan | 60 |
| refractive_index | 57 | 1.433 | 1.456 | 293.1 | 294.4 | 57 |
| saturates_vol_pct | 57 | 75.8 | 90.3 | nan | nan | 57 |
| smoke_point_mm | 2197 | 10 | 58.6 | nan | nan | 2197 |
| specific_heat_capacity_j_g_k | 50 | 1.196 | 1.907 | 273.1 | 273.1 | 50 |
| specific_heat_capacity_slope | 50 | 0.002 | 0.005 | nan | nan | 50 |
| speed_of_sound_m_s | 170 | 1363 | 1604 | 234.3 | 277.9 | 57 |
| sulfur_mercaptan_wt_ppm | 57 | 0 | 20 | nan | nan | 57 |
| sulfur_total_by_hplc_class_ppm_wt | 57 | 0 | 2597 | nan | nan | 57 |
| sulfur_wt_ppm | 57 | 7 | 2453 | nan | nan | 57 |
| surface_tension_mn_m | 135 | 23.22 | 29.08 | 263.1 | 313.1 | 54 |
| thermal_stability_break_point_C | 53 | 235 | 370 | nan | nan | 53 |
| thermal_stability_spent_fuel_mL | 176 | 459 | 650 | nan | nan | 176 |
| thiols_sulfides_disulfides_ppm_wt | 57 | -6 | 1493 | nan | nan | 57 |
| thiophenes_ppm_wt | 57 | 0 | 97 | nan | nan | 57 |
| vapor_pressure_d2879_kpa | 76 | 0.19 | 85.34 | 298.1 | 338.8 | 19 |
| vapor_pressure_d6378_kpa | 76 | 0.83 | 101.5 | 298.1 | 338.8 | 19 |
| vapor_pressure_kPa | 6500 | 0 | 1000 | 230 | 520 | 268 |
| viscosity_dyn_mPas | 18932 | 0.084 | 2718 | 230.3 | 453.1 | 812 |
| viscosity_kin_cSt | 2664 | 0.19 | 43.01 | -40 | 448.3 | 2165 |

## Multi-component coverage (n_comp >= 3, hydrocarbon)

| property | n |
|---|---|
| dcn | 133 |
| density_kg_m3 | 897 |
| flash_point_C | 3 |
| mon | 76 |
| vapor_pressure_kPa | 64 |
| viscosity_dyn_mPas | 625 |

## Real fuels (AJFTD)
| property | n |
|---|---|
| acid_number_mg_koh_g | 53 |
| aromatics_vol_pct | 77 |
| benzothiophenes_ppm_wt | 57 |
| cloud_point_C | 3 |
| conductivity_ps_m | 171 |
| d86_residue_pct | 57 |
| density_kg_m3 | 3056 |
| dibenzothiophenes_ppm_wt | 57 |
| dielectric_constant | 340 |
| distillation_T0.025_C | 12 |
| distillation_T0_C | 1760 |
| distillation_T100_C | 2239 |
| distillation_T10_C | 2252 |
| distillation_T15_C | 33 |
| distillation_T20_C | 707 |
| distillation_T25_C | 33 |
| distillation_T30_C | 94 |
| distillation_T35_C | 33 |
| distillation_T40_C | 94 |
| distillation_T45_C | 33 |
| distillation_T50_C | 2254 |
| distillation_T55_C | 33 |
| distillation_T5_C | 264 |
| distillation_T60_C | 94 |
| distillation_T65_C | 33 |
| distillation_T70_C | 94 |
| distillation_T75_C | 33 |
| distillation_T80_C | 94 |
| distillation_T85_C | 34 |
| distillation_T90_C | 2239 |
| distillation_T95_C | 250 |
| distillation_loss_pct | 2504 |
| distillation_recovery_pct | 804 |
| distillation_residue_pct | 2512 |
| flash_point_C | 2349 |
| freezing_point_C | 2278 |
| gas_solubility_air_ppm_wt | 18 |
| gas_solubility_ar_ppm_wt | 18 |
| gas_solubility_n2_ppm_wt | 18 |
| gas_solubility_o2_ppm_wt | 18 |
| hydrogen_wt_pct | 57 |
| lubricity_wear_scar_mm | 57 |
| naphthalenes_vol_pct | 57 |
| net_heat_content_btu_lb | 57 |
| net_heat_content_calculated_method_btu_lb | 57 |
| nitrogen_solubility_ppm_wt | 19 |
| olefins_vol_pct | 57 |
| polar_species_final_0.6min_elution_mg_l | 19 |
| polar_species_total_mg_l | 20 |
| pour_point_C | 60 |
| refractive_index | 57 |
| saturates_vol_pct | 57 |
| smoke_point_mm | 2197 |
| specific_heat_capacity_j_g_k | 50 |
| specific_heat_capacity_slope | 50 |
| speed_of_sound_m_s | 170 |
| sulfur_mercaptan_wt_ppm | 57 |
| sulfur_total_by_hplc_class_ppm_wt | 57 |
| sulfur_wt_ppm | 57 |
| surface_tension_mn_m | 135 |
| thermal_stability_break_point_C | 53 |
| thermal_stability_spent_fuel_mL | 176 |
| thiols_sulfides_disulfides_ppm_wt | 57 |
| thiophenes_ppm_wt | 57 |
| vapor_pressure_d2879_kpa | 76 |
| vapor_pressure_d6378_kpa | 76 |
| viscosity_kin_cSt | 2569 |

Records with >=1 outlier observation (>25 % from median, >=3 obs): 234; records backed by >=3 independent references: 1905

Conflicts by source combination:
| sources | n |
|---|---|
| ajftd | 415 |
| ajftd+crc647 | 161 |
| chew2024 | 1 |
| chew2024+leenhouts | 9 |
| chew2024+leenhouts+nist_tde | 2 |
| chew2024+leenhouts+nist_tde+thermoml | 1 |
| chew2024+leenhouts+thermoml | 1 |
| chew2024+nist_tde | 3 |
| chew2024+nist_tde+thermoml | 1 |
| chew2024+thermoml | 2 |
| crc647 | 208 |
| flashpoint_li | 28 |
| flashpoint_li+leenhouts | 18 |
| flashpoint_li+leenhouts+saldana11 | 124 |
| flashpoint_li+saldana11 | 71 |
| leenhouts | 1 |
| leenhouts+nist_tde | 20 |
| leenhouts+nist_tde+thermoml | 3 |
| leenhouts+thermoml | 3 |
| nist_tde | 8 |
| nist_tde+thermoml | 4 |
| pure_freezing_nist | 1 |
| thermoml | 114 |

## Conflicts between sources (largest first)

| property | system_id | T_K | n_obs | n_refs | sources | q25 | q75 |
|---|---|---|---|---|---|---|---|
| viscosity_dyn_mPas | 53d05b0c6200 | 293.1 | 2 | 2 | nist_tde | 817.9 | 2447 |
| viscosity_dyn_mPas | 53d05b0c6200 | 303.1 | 3 | 3 | nist_tde | 2.6 | 1292 |
| viscosity_dyn_mPas | 53d05b0c6200 | 313.1 | 2 | 2 | nist_tde | 524.3 | 1569 |
| density_kg_m3 | fuel:8 | 15 | 2 | 2 | ajftd | 197.6 | 591.2 |
| density_kg_m3 | fuel:244 | 15 | 2 | 2 | ajftd | 195.8 | 585.9 |
| density_kg_m3 | fuel:243 | 15 | 2 | 2 | ajftd | 189.6 | 567.2 |
| viscosity_dyn_mPas | 7c769ae8660b | 323.1 | 4 | 4 | chew2024+nist_tde | 1.115 | 276.8 |
| flash_point_C | 71b7c1e984bd | nan | 2 | 1 | flashpoint_li | 56.18 | 150.7 |
| distillation_T0_C | fuel:606 | nan | 4 | 4 | ajftd+crc647 | 90.09 | 151.7 |
| flash_point_C | 0237eba3f58a | nan | 3 | 1 | flashpoint_li | 38.08 | 96.65 |

## Physics-input coverage (what the baselines need)

Flash-point records (HC): 915; distinct components: 789
- with Antoine set: 92/789; Antoine range covers 40-100 C: 42
- with LFL: 460/789
- records where the physics flash-point model can run (all components have LFL + in-range Antoine): **99/915**

Viscosity records (HC): 18932; components with a measured pure density (needed for kinematic/Refutas): 17270/18932 records fully covered

## Notes / warnings
- dedupe: removed 3478 exact repeat rows (same source/ref/value)
- domain filter: dropped 101 density_kg_m3 rows (T outside 230-470 K)
- domain filter: dropped 25 density_kg_m3 rows (value outside 400-1300)
- domain filter: dropped 40 flash_point_C rows (value outside -90-250)
- domain filter: dropped 4169 vapor_pressure_kPa rows (value outside 1e-06-1000)
- domain filter: dropped 43 viscosity_dyn_mPas rows (T outside 230-470 K)
- domain filter: dropped 70 viscosity_dyn_mPas rows (value outside 0.05-100000)
- domain filter: dropped 879 vapor_pressure_kPa rows (T outside 230-520 K)