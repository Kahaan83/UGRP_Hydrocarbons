# Inventory

- table files: 320 (210 in splits/)
- other files (weights, logs, ...): 63


## leenhouts_benchmark\datasets\datasets\flashpoint\processed_data\flashpoint_mix_exp.csv
- rows: 1006, cols: 11
- columns: ['value', 'unit', 'fraction_type', 'component_inchi_0', 'component_inchi_1', 'component_inchi_2', 'component_inchi_3', 'fraction_0', 'fraction_1', 'fraction_2', 'fraction_3']
```
   value     unit fraction_type                    component_inchi_0                    component_inchi_1                    component_inchi_2  component_inchi_3  fraction_0  fraction_1  fraction_2  fraction_3
0  71.85  Celcius         molar  InChI=1S/C10H22/c1-3-5-7-9-10-8-...  InChI=1S/C12H26/c1-3-5-7-9-11-12...  InChI=1S/C14H30/c1-3-5-7-9-11-13...                NaN       0.251       0.210       0.539         NaN
1  65.35  Celcius         molar  InChI=1S/C10H22/c1-3-5-7-9-10-8-...  InChI=1S/C12H26/c1-3-5-7-9-11-12...  InChI=1S/C14H30/c1-3-5-7-9-11-13...                NaN       0.392       0.327       0.281         NaN
```

## leenhouts_benchmark\datasets\datasets\flashpoint\processed_data\flashpoint_mix_exp_with_ideal.csv
- rows: 1006, cols: 13
- columns: ['value', 'unit', 'fraction_type', 'component_inchi_0', 'component_inchi_1', 'component_inchi_2', 'component_inchi_3', 'fraction_0', 'fraction_1', 'fraction_2', 'fraction_3', 'ideal_value', 'excess_value']
```
   value     unit fraction_type                    component_inchi_0                    component_inchi_1                    component_inchi_2  component_inchi_3  fraction_0  fraction_1  fraction_2  fraction_3  ideal_value  excess_value
0  71.85  Celcius         molar  InChI=1S/C10H22/c1-3-5-7-9-10-8-...  InChI=1S/C12H26/c1-3-5-7-9-11-12...  InChI=1S/C14H30/c1-3-5-7-9-11-13...                NaN       0.251       0.210       0.539         NaN       80.986        -9.136
1  65.35  Celcius         molar  InChI=1S/C10H22/c1-3-5-7-9-10-8-...  InChI=1S/C12H26/c1-3-5-7-9-11-12...  InChI=1S/C14H30/c1-3-5-7-9-11-13...                NaN       0.392       0.327       0.281         NaN       70.330        -4.980
```

## leenhouts_benchmark\datasets\datasets\flashpoint\processed_data\flashpoint_pure_exp.csv
- rows: 585, cols: 3
- columns: ['value', 'unit', 'component_inchi_0']
```
   value     unit                    component_inchi_0
0  146.0  Celcius  InChI=1S/C10H10O4/c1-13-9(11)7-5...
1   77.0  Celcius  InChI=1S/C10H12/c1-2-6-10-8-4-3-...
```

## leenhouts_benchmark\datasets\datasets\fuel_ignition_numbers\processed_data\dcn_mix_exp.csv
- rows: 484, cols: 11
- columns: ['value', 'unit', 'fraction_type', 'component_inchi_0', 'component_inchi_1', 'component_inchi_2', 'component_inchi_3', 'fraction_0', 'fraction_1', 'fraction_2', 'fraction_3']
```
   value unit fraction_type                    component_inchi_0                    component_inchi_1                    component_inchi_2                    component_inchi_3  fraction_0  fraction_1  fraction_2  fraction_3
0   70.0    -         molar  InChI=1S/C10H12/c1-2-6-10-8-4-3-...  InChI=1S/C11H24/c1-3-5-7-9-11-10...  InChI=1S/C14H30/c1-3-5-7-9-11-13...  InChI=1S/C7H16/c1-3-5-7-6-4-2/h3...         0.1         0.5         0.3         0.1
1   51.3    -         molar  InChI=1S/C10H12/c1-2-6-10-8-4-3-...  InChI=1S/C11H24/c1-3-5-7-9-11-10...  InChI=1S/C14H30/c1-3-5-7-9-11-13...  InChI=1S/C7H16/c1-3-5-7-6-4-2/h3...         0.2         0.1         0.1         0.6
```

## leenhouts_benchmark\datasets\datasets\fuel_ignition_numbers\processed_data\dcn_mix_exp_with_ideal.csv
- rows: 484, cols: 13
- columns: ['value', 'unit', 'fraction_type', 'component_inchi_0', 'component_inchi_1', 'component_inchi_2', 'component_inchi_3', 'fraction_0', 'fraction_1', 'fraction_2', 'fraction_3', 'ideal_value', 'excess_value']
```
   value unit fraction_type                    component_inchi_0                    component_inchi_1                    component_inchi_2                    component_inchi_3  fraction_0  fraction_1  fraction_2  fraction_3  ideal_value  excess_value
0   70.0    -         molar  InChI=1S/C10H12/c1-2-6-10-8-4-3-...  InChI=1S/C11H24/c1-3-5-7-9-11-10...  InChI=1S/C14H30/c1-3-5-7-9-11-13...  InChI=1S/C7H16/c1-3-5-7-6-4-2/h3...         0.1         0.5         0.3         0.1          NaN           NaN
1   51.3    -         molar  InChI=1S/C10H12/c1-2-6-10-8-4-3-...  InChI=1S/C11H24/c1-3-5-7-9-11-10...  InChI=1S/C14H30/c1-3-5-7-9-11-13...  InChI=1S/C7H16/c1-3-5-7-6-4-2/h3...         0.2         0.1         0.1         0.6          NaN           NaN
```

## leenhouts_benchmark\datasets\datasets\fuel_ignition_numbers\processed_data\dcn_pure_exp.csv
- rows: 229, cols: 3
- columns: ['value', 'unit', 'component_inchi_0']
```
   value unit                    component_inchi_0
0    9.0    -  InChI=1S/C10H12/c1-2-6-10-8-4-3-...
1   12.5    -  InChI=1S/C10H14/c1-2-3-7-10-8-5-...
```

## leenhouts_benchmark\datasets\datasets\fuel_ignition_numbers\processed_data\mon_mix_exp.csv
- rows: 292, cols: 165
- columns: ['value', 'unit', 'fraction_type', 'component_inchi_0', 'component_inchi_1', 'component_inchi_2', 'component_inchi_3', 'component_inchi_4', 'component_inchi_5', 'component_inchi_6', 'component_inchi_7', 'component_inchi_8', 'component_inchi_9', 'component_inchi_10', 'component_inchi_11', 'component_inchi_12', 'component_inchi_13', 'component_inchi_14', 'component_inchi_15', 'component_inchi_16', 'component_inchi_17', 'component_inchi_18', 'component_inchi_19', 'component_inchi_20', 'component_inchi_21', 'component_inchi_22', 'component_inchi_23', 'component_inchi_24', 'component_inchi_25', 'component_inchi_26', 'component_inchi_27', 'component_inchi_28', 'component_inchi_29', 'component_inchi_30', 'component_inchi_31', 'component_inchi_32', 'component_inchi_33', 'component_inchi_34', 'component_inchi_35', 'component_inchi_36']
```
   value unit fraction_type                    component_inchi_0                    component_inchi_1                    component_inchi_2                    component_inchi_3                    component_inchi_4                    component_inchi_5                    component_inchi_6                    component_inchi_7                    component_inchi_8                    component_inchi_9                   component_inchi_10                   component_inchi_11                   component_inchi_12                   component_inchi_13                   component_inchi_14                   component_inchi_15                   component_inchi_16                   component_inchi_17                  component_inchi_18                   component_inchi_19                   component_inchi_20                   component_inchi_21                   component_inchi_22                   component_inchi_23                   component_inchi_24                   component_inchi_25                   component_inchi_26                   component_inchi_27                   component_inchi_28                   component_inchi_29                   component_inchi_30                   component_inchi_31                   component_inchi_32                   component_inchi_33                   component_inchi_34                   component_inchi_35                   component_inchi_36                   component_inchi_37                   component_inchi_38                   component_inchi_39                   component_inchi_40                   component_inchi_41                   component_inchi_42                   component_inchi_43                   component_inchi_44                   component_inchi_45                   component_inchi_46                   component_inchi_47                   component_inchi_48                   component_inchi_49                   component_inchi_50                   component_inchi_51                   component_inchi_52                   component_inchi_53                   component_inchi_54                   component_inchi_55                   component_inchi_56                   component_inchi_57                   component_inchi_58                   component_inchi_59                   component_inchi_60                   component_inchi_61                   component_inchi_62                   component_inchi_63                   component_inchi_64                   component_inchi_65                   component_inchi_66                   component_inchi_67                   component_inchi_68                   component_inchi_69                   component_inchi_70                   component_inchi_71                   component_inchi_72                   component_inchi_73                   component_inchi_74                   component_inchi_75                   component_inchi_76                   component_inchi_77                   component_inchi_78                   component_inchi_79                   component_inchi_80  fraction_0  fraction_1  fraction_2  fraction_3  fraction_4  fraction_5  fraction_6  fraction_7  fraction_8  fraction_9  fraction_10  fraction_11  fraction_12  fraction_13  fraction_14  fraction_15  fraction_16  fraction_17  fraction_18  fraction_19  fraction_20  fraction_21  fraction_22  fraction_23  fraction_24  fraction_25  fraction_26  fraction_27  fraction_28  fraction_29  fraction_30  fraction_31  fraction_32  fraction_33  fraction_34  fraction_35  fraction_36  fraction_37  fraction_38  fraction_39  fraction_40  fraction_41  fraction_42  fraction_43  fraction_44  fraction_45  fraction_46  fraction_47  fraction_48  fraction_49  fraction_50  fraction_51  fraction_52  fraction_53  fraction_54  fraction_55  fraction_56  fraction_57  fraction_58  fraction_59  fraction_60  fraction_61  fraction_62  fraction_63  fraction_64  fraction_65  fraction_66  fraction_67  fraction_68  fraction_69  fraction_70  fraction_71  fraction_72  fraction_73  fraction_74  fraction_75  fraction_76  fraction_77  fraction_78  fraction_79  fraction_80
0   86.1    -         molar  InChI=1S/C10H10/c1-8-6-7-9-4-2-3...  InChI=1S/C10H14/c1-10(2,3)9-7-5-...  InChI=1S/C10H14/c1-4-10-6-5-8(2)...  InChI=1S/C10H14/c1-4-10-6-8(2)5-...  InChI=1S/C10H14/c1-4-10-7-8(2)5-...  InChI=1S/C10H14/c1-4-10-8(2)6-5-...  InChI=1S/C10H14/c1-7-5-9(3)10(4)...  InChI=1S/C10H14/c1-8(2)10-6-4-5-...  InChI=1S/C10H22/c1-4-5-6-7-8-9-1...  InChI=1S/C10H22/c1-4-6-7-8-9-10(...  InChI=1S/C10H22/c1-5-9(4)8-10(6-...  InChI=1S/C11H14/c1-8-7-10-5-3-4-...  InChI=1S/C11H16/c1-3-4-8-11-9-6-...  InChI=1S/C11H16/c1-4-10-5-7-11(8...  InChI=1S/C11H16/c1-4-10-6-9(3)7-...  InChI=1S/C11H16/c1-9-5-7-10(8-6-...  InChI=1S/C12H18/c1-6-12-10(4)8(2...  InChI=1S/C12H26/c1-3-5-7-9-11-12...   InChI=1S/C2H6O/c1-2-3/h3H,2H2,1H3  InChI=1S/C4H10/c1-3-4-2/h3-4H2,1...   InChI=1S/C5H10/c1-2-4-5-3-1/h1-5H2  InChI=1S/C5H10/c1-3-5-4-2/h3,5H,...  InChI=1S/C5H10/c1-3-5-4-2/h3,5H,...  InChI=1S/C5H10/c1-3-5-4-2/h3H,1,...  InChI=1S/C5H10/c1-4-5(2)3/h2,4H2...  InChI=1S/C5H10/c1-4-5(2)3/h4H,1-3H3  InChI=1S/C5H12/c1-3-5-4-2/h3-5H2...  InChI=1S/C5H12/c1-4-5(2)3/h5H,4H...  InChI=1S/C5H8/c1-2-4-5-3-1/h1-2H...  InChI=1S/C6H10/c1-6-4-2-3-5-6/h2...  InChI=1S/C6H10/c1-6-4-2-3-5-6/h4...  InChI=1S/C6H12/c1-2-4-6-5-3-1/h1...  InChI=1S/C6H12/c1-3-5-6-4-2/h3,5...  InChI=1S/C6H12/c1-3-5-6-4-2/h3H,...  InChI=1S/C6H12/c1-3-5-6-4-2/h5-6...  InChI=1S/C6H12/c1-3-5-6-4-2/h5-6...  InChI=1S/C6H12/c1-4-5-6(2)3/h2,4...  InChI=1S/C6H12/c1-4-5-6(2)3/h5H,...  InChI=1S/C6H12/c1-4-6(3)5-2/h4H,...  InChI=1S/C6H12/c1-5(2)6(3)4/h6H,...  InChI=1S/C6H12/c1-6-4-2-3-5-6/h6...  InChI=1S/C6H14/c1-3-5-6-4-2/h3-6...  InChI=1S/C6H14/c1-4-5-6(2)3/h6H,...  InChI=1S/C6H14/c1-4-6(3)5-2/h6H,...  InChI=1S/C6H14/c1-5-6(2,3)4/h5H2...   InChI=1S/C6H6/c1-2-4-6-5-3-1/h1-6H  InChI=1S/C7H14/c1-2-7-5-3-4-6-7/...  InChI=1S/C7H14/c1-6-3-4-7(2)5-6/...  InChI=1S/C7H14/c1-6-3-4-7(2)5-6/...  InChI=1S/C7H14/c1-6-4-3-5-7(6)2/...  InChI=1S/C7H14/c1-7-5-3-2-4-6-7/...  InChI=1S/C7H16/c1-3-5-7-6-4-2/h3...  InChI=1S/C7H16/c1-4-5-6-7(2)3/h7...  InChI=1S/C7H16/c1-4-6-7(3)5-2/h7...  InChI=1S/C7H16/c1-4-7(5-2)6-3/h7...  InChI=1S/C7H16/c1-5-7(4)6(2)3/h6...  InChI=1S/C7H16/c1-6(2)5-7(3)4/h6...  InChI=1S/C7H8/c1-7-5-3-2-4-6-7/h...  InChI=1S/C8H10/c1-2-8-6-4-3-5-7-...  InChI=1S/C8H10/c1-7-3-5-8(2)6-4-...  InChI=1S/C8H10/c1-7-4-3-5-8(2)6-...  InChI=1S/C8H10/c1-7-5-3-4-6-8(7)...  InChI=1S/C8H16/c1-6-4-5-7(2)8(6)...  InChI=1S/C8H16/c1-7-4-3-5-8(2)6-...  InChI=1S/C8H18/c1-3-5-7-8-6-4-2/...  InChI=1S/C8H18/c1-4-5-6-7-8(2)3/...  InChI=1S/C8H18/c1-4-6-8(3)7-5-2/...  InChI=1S/C8H18/c1-5-8(4)6-7(2)3/...  InChI=1S/C8H18/c1-5-8(6-2)7(3)4/...  InChI=1S/C8H18/c1-6(2)8(5)7(3)4/...  InChI=1S/C8H18/c1-6-7(2)8(3,4)5/...  InChI=1S/C8H18/c1-7(2)5-6-8(3)4/...  InChI=1S/C8H18/c1-7(2)6-8(3,4)5/...  InChI=1S/C9H12/c1-3-9-6-4-5-8(2)...  InChI=1S/C9H12/c1-3-9-7-5-4-6-8(...  InChI=1S/C9H12/c1-7-4-5-8(2)9(3)...  InChI=1S/C9H12/c1-7-4-8(2)6-9(3)...  InChI=1S/C9H12/c1-7-5-4-6-8(2)9(...  InChI=1S/C9H12/c1-8(2)9-6-4-3-5-...  InChI=1S/C9H20/c1-3-5-7-9-8-6-4-...  InChI=1S/C9H20/c1-8(2)6-7-9(3,4)...       0.001       0.002       0.006       0.005       0.003       0.003       0.004       0.002       0.002       0.002        0.057        0.005        0.004        0.004        0.003        0.002        0.004        0.002        0.102        0.036        0.075        0.008        0.004        0.003        0.006        0.012        0.007        0.005        0.001        0.001        0.003        0.003        0.003        0.003        0.001        0.003        0.002        0.002        0.003        0.007        0.008        0.005        0.019        0.011        0.033        0.004        0.002        0.003        0.003        0.002        0.005        0.012        0.015        0.015        0.002        0.030        0.015        0.036        0.006        0.005        0.014        0.017        0.002        0.003        0.005        0.005        0.002        0.008        0.006        0.028        0.002        0.005        0.088         0.02         0.02        0.089        0.026        0.017        0.003        0.002        0.006
1   83.4    -         molar  InChI=1S/C10H14/c1-10(2,3)9-7-5-...  InChI=1S/C10H14/c1-4-10-6-5-8(2)...  InChI=1S/C10H14/c1-4-10-6-8(2)5-...  InChI=1S/C10H14/c1-4-10-8(2)6-5-...  InChI=1S/C10H14/c1-8(2)10-6-4-5-...  InChI=1S/C10H22/c1-4-6-7-9-10(3)...  InChI=1S/C10H22/c1-5-6-7-8-10(4)...  InChI=1S/C10H22/c1-5-9(3)7-8-10(...  InChI=1S/C10H22/c1-5-9(4)8-10(6-...  InChI=1S/C10H22/c1-8(2)6-10(5)7-...  InChI=1S/C10H22/c1-9(2)7-5-6-8-1...  InChI=1S/C11H14/c1-8-7-10-5-3-4-...  InChI=1S/C11H16/c1-4-10-7-5-6-8-...  InChI=1S/C11H24/c1-7-9(2)8-10(3)...    InChI=1S/C2H6O/c1-2-3/h3H,2H2,1H3      InChI=1S/C3H8/c1-3-2/h3H2,1-2H3  InChI=1S/C4H10/c1-3-4-2/h3-4H2,1...    InChI=1S/C4H10/c1-4(2)3/h4H,1-3H3  InChI=1S/C5H10/c1-2-4-5-3-1/h1-5H2  InChI=1S/C5H12/c1-3-5-4-2/h3-5H2...  InChI=1S/C5H12/c1-4-5(2)3/h5H,4H...  InChI=1S/C6H12/c1-2-4-6-5-3-1/h1...  InChI=1S/C6H12/c1-3-5-6-4-2/h3H,...  InChI=1S/C6H12/c1-5(2)6(3)4/h6H,...  InChI=1S/C6H12/c1-6-4-2-3-5-6/h6...  InChI=1S/C6H14/c1-3-5-6-4-2/h3-6...  InChI=1S/C6H14/c1-4-5-6(2)3/h6H,...  InChI=1S/C6H14/c1-4-6(3)5-2/h6H,...  InChI=1S/C6H14/c1-5-6(2,3)4/h5H2...   InChI=1S/C6H6/c1-2-4-6-5-3-1/h1-6H  InChI=1S/C7H14/c1-2-7-5-3-4-6-7/...  InChI=1S/C7H14/c1-6-3-4-7(2)5-6/...  InChI=1S/C7H14/c1-6-3-4-7(2)5-6/...  InChI=1S/C7H14/c1-6-4-3-5-7(6)2/...  InChI=1S/C7H14/c1-6-4-3-5-7(6)2/...  InChI=1S/C7H16/c1-3-5-7-6-4-2/h3...  InChI=1S/C7H16/c1-4-5-6-7(2)3/h7...  InChI=1S/C7H16/c1-4-6-7(3)5-2/h7...  InChI=1S/C7H16/c1-5-6-7(2,3)4/h5...  InChI=1S/C7H16/c1-5-7(4)6(2)3/h6...  InChI=1S/C7H16/c1-6(2)5-7(3)4/h6...  InChI=1S/C7H8/c1-7-5-3-2-4-6-7/h...  InChI=1S/C8H10/c1-2-8-6-4-3-5-7-...  InChI=1S/C8H10/c1-7-3-5-8(2)6-4-...  InChI=1S/C8H10/c1-7-4-3-5-8(2)6-...  InChI=1S/C8H10/c1-7-5-3-4-6-8(7)...  InChI=1S/C8H16/c1-6-4-5-7(2)8(6)...  InChI=1S/C8H16/c1-7-3-5-8(2)6-4-...  InChI=1S/C8H16/c1-7-4-5-8(2,3)6-...  InChI=1S/C8H18/c1-3-5-7-8-6-4-2/...  InChI=1S/C8H18/c1-5-6-7-8(2,3)4/...  InChI=1S/C8H18/c1-5-7(3)8(4)6-2/...  InChI=1S/C8H18/c1-5-8(4)6-7(2)3/...  InChI=1S/C8H18/c1-5-8(4,6-2)7-3/...  InChI=1S/C8H18/c1-5-8(6-2)7(3)4/...  InChI=1S/C8H18/c1-6-7(2)8(3,4)5/...  InChI=1S/C8H18/c1-7(2)5-6-8(3)4/...  InChI=1S/C9H12/c1-3-9-7-5-4-6-8(...  InChI=1S/C9H12/c1-7-4-5-8(2)9(3)...  InChI=1S/C9H12/c1-7-5-4-6-8(2)9(...  InChI=1S/C9H18/c1-7-4-5-8(2)9(3)...  InChI=1S/C9H18/c1-7-5-4-6-8(2)9(...  InChI=1S/C9H18/c1-8-4-6-9(2,3)7-...  InChI=1S/C9H18/c1-8-5-4-6-9(2,3)...  InChI=1S/C9H20/c1-3-5-7-9-8-6-4-...  InChI=1S/C9H20/c1-8(2)6-7-9(3,4)...                                  NaN                                  NaN                                  NaN                                  NaN                                  NaN                                  NaN                                  NaN                                  NaN                                  NaN                                  NaN                                  NaN                                  NaN                                  NaN                                  NaN                                  NaN       0.006       0.002       0.003       0.005       0.001       0.035       0.012       0.009       0.020       0.006        0.003        0.001        0.002        0.005        0.084        0.001        0.012        0.002        0.054        0.040        0.047        0.022        0.055        0.008        0.006        0.027        0.028        0.012        0.027        0.008        0.004        0.001        0.001        0.017        0.002        0.025        0.010        0.010        0.001        0.005        0.006        0.090        0.018        0.013        0.030        0.009        0.019        0.006        0.040        0.018        0.016        0.003        0.007        0.008        0.006        0.003        0.007        0.002        0.033        0.006        0.004        0.004        0.002        0.002        0.014        0.015          NaN          NaN          NaN          NaN          NaN          NaN          NaN          NaN          NaN          NaN          NaN          NaN          NaN          NaN          NaN
```

## leenhouts_benchmark\datasets\datasets\fuel_ignition_numbers\processed_data\mon_mix_exp_with_ideal.csv
- rows: 292, cols: 167
- columns: ['value', 'unit', 'fraction_type', 'component_inchi_0', 'component_inchi_1', 'component_inchi_2', 'component_inchi_3', 'component_inchi_4', 'component_inchi_5', 'component_inchi_6', 'component_inchi_7', 'component_inchi_8', 'component_inchi_9', 'component_inchi_10', 'component_inchi_11', 'component_inchi_12', 'component_inchi_13', 'component_inchi_14', 'component_inchi_15', 'component_inchi_16', 'component_inchi_17', 'component_inchi_18', 'component_inchi_19', 'component_inchi_20', 'component_inchi_21', 'component_inchi_22', 'component_inchi_23', 'component_inchi_24', 'component_inchi_25', 'component_inchi_26', 'component_inchi_27', 'component_inchi_28', 'component_inchi_29', 'component_inchi_30', 'component_inchi_31', 'component_inchi_32', 'component_inchi_33', 'component_inchi_34', 'component_inchi_35', 'component_inchi_36']
```
   value unit fraction_type                    component_inchi_0                    component_inchi_1                    component_inchi_2                    component_inchi_3                    component_inchi_4                    component_inchi_5                    component_inchi_6                    component_inchi_7                    component_inchi_8                    component_inchi_9                   component_inchi_10                   component_inchi_11                   component_inchi_12                   component_inchi_13                   component_inchi_14                   component_inchi_15                   component_inchi_16                   component_inchi_17                  component_inchi_18                   component_inchi_19                   component_inchi_20                   component_inchi_21                   component_inchi_22                   component_inchi_23                   component_inchi_24                   component_inchi_25                   component_inchi_26                   component_inchi_27                   component_inchi_28                   component_inchi_29                   component_inchi_30                   component_inchi_31                   component_inchi_32                   component_inchi_33                   component_inchi_34                   component_inchi_35                   component_inchi_36                   component_inchi_37                   component_inchi_38                   component_inchi_39                   component_inchi_40                   component_inchi_41                   component_inchi_42                   component_inchi_43                   component_inchi_44                   component_inchi_45                   component_inchi_46                   component_inchi_47                   component_inchi_48                   component_inchi_49                   component_inchi_50                   component_inchi_51                   component_inchi_52                   component_inchi_53                   component_inchi_54                   component_inchi_55                   component_inchi_56                   component_inchi_57                   component_inchi_58                   component_inchi_59                   component_inchi_60                   component_inchi_61                   component_inchi_62                   component_inchi_63                   component_inchi_64                   component_inchi_65                   component_inchi_66                   component_inchi_67                   component_inchi_68                   component_inchi_69                   component_inchi_70                   component_inchi_71                   component_inchi_72                   component_inchi_73                   component_inchi_74                   component_inchi_75                   component_inchi_76                   component_inchi_77                   component_inchi_78                   component_inchi_79                   component_inchi_80  fraction_0  fraction_1  fraction_2  fraction_3  fraction_4  fraction_5  fraction_6  fraction_7  fraction_8  fraction_9  fraction_10  fraction_11  fraction_12  fraction_13  fraction_14  fraction_15  fraction_16  fraction_17  fraction_18  fraction_19  fraction_20  fraction_21  fraction_22  fraction_23  fraction_24  fraction_25  fraction_26  fraction_27  fraction_28  fraction_29  fraction_30  fraction_31  fraction_32  fraction_33  fraction_34  fraction_35  fraction_36  fraction_37  fraction_38  fraction_39  fraction_40  fraction_41  fraction_42  fraction_43  fraction_44  fraction_45  fraction_46  fraction_47  fraction_48  fraction_49  fraction_50  fraction_51  fraction_52  fraction_53  fraction_54  fraction_55  fraction_56  fraction_57  fraction_58  fraction_59  fraction_60  fraction_61  fraction_62  fraction_63  fraction_64  fraction_65  fraction_66  fraction_67  fraction_68  fraction_69  fraction_70  fraction_71  fraction_72  fraction_73  fraction_74  fraction_75  fraction_76  fraction_77  fraction_78  fraction_79  fraction_80  ideal_value  excess_value
0   86.1    -         molar  InChI=1S/C10H10/c1-8-6-7-9-4-2-3...  InChI=1S/C10H14/c1-10(2,3)9-7-5-...  InChI=1S/C10H14/c1-4-10-6-5-8(2)...  InChI=1S/C10H14/c1-4-10-6-8(2)5-...  InChI=1S/C10H14/c1-4-10-7-8(2)5-...  InChI=1S/C10H14/c1-4-10-8(2)6-5-...  InChI=1S/C10H14/c1-7-5-9(3)10(4)...  InChI=1S/C10H14/c1-8(2)10-6-4-5-...  InChI=1S/C10H22/c1-4-5-6-7-8-9-1...  InChI=1S/C10H22/c1-4-6-7-8-9-10(...  InChI=1S/C10H22/c1-5-9(4)8-10(6-...  InChI=1S/C11H14/c1-8-7-10-5-3-4-...  InChI=1S/C11H16/c1-3-4-8-11-9-6-...  InChI=1S/C11H16/c1-4-10-5-7-11(8...  InChI=1S/C11H16/c1-4-10-6-9(3)7-...  InChI=1S/C11H16/c1-9-5-7-10(8-6-...  InChI=1S/C12H18/c1-6-12-10(4)8(2...  InChI=1S/C12H26/c1-3-5-7-9-11-12...   InChI=1S/C2H6O/c1-2-3/h3H,2H2,1H3  InChI=1S/C4H10/c1-3-4-2/h3-4H2,1...   InChI=1S/C5H10/c1-2-4-5-3-1/h1-5H2  InChI=1S/C5H10/c1-3-5-4-2/h3,5H,...  InChI=1S/C5H10/c1-3-5-4-2/h3,5H,...  InChI=1S/C5H10/c1-3-5-4-2/h3H,1,...  InChI=1S/C5H10/c1-4-5(2)3/h2,4H2...  InChI=1S/C5H10/c1-4-5(2)3/h4H,1-3H3  InChI=1S/C5H12/c1-3-5-4-2/h3-5H2...  InChI=1S/C5H12/c1-4-5(2)3/h5H,4H...  InChI=1S/C5H8/c1-2-4-5-3-1/h1-2H...  InChI=1S/C6H10/c1-6-4-2-3-5-6/h2...  InChI=1S/C6H10/c1-6-4-2-3-5-6/h4...  InChI=1S/C6H12/c1-2-4-6-5-3-1/h1...  InChI=1S/C6H12/c1-3-5-6-4-2/h3,5...  InChI=1S/C6H12/c1-3-5-6-4-2/h3H,...  InChI=1S/C6H12/c1-3-5-6-4-2/h5-6...  InChI=1S/C6H12/c1-3-5-6-4-2/h5-6...  InChI=1S/C6H12/c1-4-5-6(2)3/h2,4...  InChI=1S/C6H12/c1-4-5-6(2)3/h5H,...  InChI=1S/C6H12/c1-4-6(3)5-2/h4H,...  InChI=1S/C6H12/c1-5(2)6(3)4/h6H,...  InChI=1S/C6H12/c1-6-4-2-3-5-6/h6...  InChI=1S/C6H14/c1-3-5-6-4-2/h3-6...  InChI=1S/C6H14/c1-4-5-6(2)3/h6H,...  InChI=1S/C6H14/c1-4-6(3)5-2/h6H,...  InChI=1S/C6H14/c1-5-6(2,3)4/h5H2...   InChI=1S/C6H6/c1-2-4-6-5-3-1/h1-6H  InChI=1S/C7H14/c1-2-7-5-3-4-6-7/...  InChI=1S/C7H14/c1-6-3-4-7(2)5-6/...  InChI=1S/C7H14/c1-6-3-4-7(2)5-6/...  InChI=1S/C7H14/c1-6-4-3-5-7(6)2/...  InChI=1S/C7H14/c1-7-5-3-2-4-6-7/...  InChI=1S/C7H16/c1-3-5-7-6-4-2/h3...  InChI=1S/C7H16/c1-4-5-6-7(2)3/h7...  InChI=1S/C7H16/c1-4-6-7(3)5-2/h7...  InChI=1S/C7H16/c1-4-7(5-2)6-3/h7...  InChI=1S/C7H16/c1-5-7(4)6(2)3/h6...  InChI=1S/C7H16/c1-6(2)5-7(3)4/h6...  InChI=1S/C7H8/c1-7-5-3-2-4-6-7/h...  InChI=1S/C8H10/c1-2-8-6-4-3-5-7-...  InChI=1S/C8H10/c1-7-3-5-8(2)6-4-...  InChI=1S/C8H10/c1-7-4-3-5-8(2)6-...  InChI=1S/C8H10/c1-7-5-3-4-6-8(7)...  InChI=1S/C8H16/c1-6-4-5-7(2)8(6)...  InChI=1S/C8H16/c1-7-4-3-5-8(2)6-...  InChI=1S/C8H18/c1-3-5-7-8-6-4-2/...  InChI=1S/C8H18/c1-4-5-6-7-8(2)3/...  InChI=1S/C8H18/c1-4-6-8(3)7-5-2/...  InChI=1S/C8H18/c1-5-8(4)6-7(2)3/...  InChI=1S/C8H18/c1-5-8(6-2)7(3)4/...  InChI=1S/C8H18/c1-6(2)8(5)7(3)4/...  InChI=1S/C8H18/c1-6-7(2)8(3,4)5/...  InChI=1S/C8H18/c1-7(2)5-6-8(3)4/...  InChI=1S/C8H18/c1-7(2)6-8(3,4)5/...  InChI=1S/C9H12/c1-3-9-6-4-5-8(2)...  InChI=1S/C9H12/c1-3-9-7-5-4-6-8(...  InChI=1S/C9H12/c1-7-4-5-8(2)9(3)...  InChI=1S/C9H12/c1-7-4-8(2)6-9(3)...  InChI=1S/C9H12/c1-7-5-4-6-8(2)9(...  InChI=1S/C9H12/c1-8(2)9-6-4-3-5-...  InChI=1S/C9H20/c1-3-5-7-9-8-6-4-...  InChI=1S/C9H20/c1-8(2)6-7-9(3,4)...       0.001       0.002       0.006       0.005       0.003       0.003       0.004       0.002       0.002       0.002        0.057        0.005        0.004        0.004        0.003        0.002        0.004        0.002        0.102        0.036        0.075        0.008        0.004        0.003        0.006        0.012        0.007        0.005        0.001        0.001        0.003        0.003        0.003        0.003        0.001        0.003        0.002        0.002        0.003        0.007        0.008        0.005        0.019        0.011        0.033        0.004        0.002        0.003        0.003        0.002        0.005        0.012        0.015        0.015        0.002        0.030        0.015        0.036        0.006        0.005        0.014        0.017        0.002        0.003        0.005        0.005        0.002        0.008        0.006        0.028        0.002        0.005        0.088         0.02         0.02        0.089        0.026        0.017        0.003        0.002        0.006          NaN           NaN
1   83.4    -         molar  InChI=1S/C10H14/c1-10(2,3)9-7-5-...  InChI=1S/C10H14/c1-4-10-6-5-8(2)...  InChI=1S/C10H14/c1-4-10-6-8(2)5-...  InChI=1S/C10H14/c1-4-10-8(2)6-5-...  InChI=1S/C10H14/c1-8(2)10-6-4-5-...  InChI=1S/C10H22/c1-4-6-7-9-10(3)...  InChI=1S/C10H22/c1-5-6-7-8-10(4)...  InChI=1S/C10H22/c1-5-9(3)7-8-10(...  InChI=1S/C10H22/c1-5-9(4)8-10(6-...  InChI=1S/C10H22/c1-8(2)6-10(5)7-...  InChI=1S/C10H22/c1-9(2)7-5-6-8-1...  InChI=1S/C11H14/c1-8-7-10-5-3-4-...  InChI=1S/C11H16/c1-4-10-7-5-6-8-...  InChI=1S/C11H24/c1-7-9(2)8-10(3)...    InChI=1S/C2H6O/c1-2-3/h3H,2H2,1H3      InChI=1S/C3H8/c1-3-2/h3H2,1-2H3  InChI=1S/C4H10/c1-3-4-2/h3-4H2,1...    InChI=1S/C4H10/c1-4(2)3/h4H,1-3H3  InChI=1S/C5H10/c1-2-4-5-3-1/h1-5H2  InChI=1S/C5H12/c1-3-5-4-2/h3-5H2...  InChI=1S/C5H12/c1-4-5(2)3/h5H,4H...  InChI=1S/C6H12/c1-2-4-6-5-3-1/h1...  InChI=1S/C6H12/c1-3-5-6-4-2/h3H,...  InChI=1S/C6H12/c1-5(2)6(3)4/h6H,...  InChI=1S/C6H12/c1-6-4-2-3-5-6/h6...  InChI=1S/C6H14/c1-3-5-6-4-2/h3-6...  InChI=1S/C6H14/c1-4-5-6(2)3/h6H,...  InChI=1S/C6H14/c1-4-6(3)5-2/h6H,...  InChI=1S/C6H14/c1-5-6(2,3)4/h5H2...   InChI=1S/C6H6/c1-2-4-6-5-3-1/h1-6H  InChI=1S/C7H14/c1-2-7-5-3-4-6-7/...  InChI=1S/C7H14/c1-6-3-4-7(2)5-6/...  InChI=1S/C7H14/c1-6-3-4-7(2)5-6/...  InChI=1S/C7H14/c1-6-4-3-5-7(6)2/...  InChI=1S/C7H14/c1-6-4-3-5-7(6)2/...  InChI=1S/C7H16/c1-3-5-7-6-4-2/h3...  InChI=1S/C7H16/c1-4-5-6-7(2)3/h7...  InChI=1S/C7H16/c1-4-6-7(3)5-2/h7...  InChI=1S/C7H16/c1-5-6-7(2,3)4/h5...  InChI=1S/C7H16/c1-5-7(4)6(2)3/h6...  InChI=1S/C7H16/c1-6(2)5-7(3)4/h6...  InChI=1S/C7H8/c1-7-5-3-2-4-6-7/h...  InChI=1S/C8H10/c1-2-8-6-4-3-5-7-...  InChI=1S/C8H10/c1-7-3-5-8(2)6-4-...  InChI=1S/C8H10/c1-7-4-3-5-8(2)6-...  InChI=1S/C8H10/c1-7-5-3-4-6-8(7)...  InChI=1S/C8H16/c1-6-4-5-7(2)8(6)...  InChI=1S/C8H16/c1-7-3-5-8(2)6-4-...  InChI=1S/C8H16/c1-7-4-5-8(2,3)6-...  InChI=1S/C8H18/c1-3-5-7-8-6-4-2/...  InChI=1S/C8H18/c1-5-6-7-8(2,3)4/...  InChI=1S/C8H18/c1-5-7(3)8(4)6-2/...  InChI=1S/C8H18/c1-5-8(4)6-7(2)3/...  InChI=1S/C8H18/c1-5-8(4,6-2)7-3/...  InChI=1S/C8H18/c1-5-8(6-2)7(3)4/...  InChI=1S/C8H18/c1-6-7(2)8(3,4)5/...  InChI=1S/C8H18/c1-7(2)5-6-8(3)4/...  InChI=1S/C9H12/c1-3-9-7-5-4-6-8(...  InChI=1S/C9H12/c1-7-4-5-8(2)9(3)...  InChI=1S/C9H12/c1-7-5-4-6-8(2)9(...  InChI=1S/C9H18/c1-7-4-5-8(2)9(3)...  InChI=1S/C9H18/c1-7-5-4-6-8(2)9(...  InChI=1S/C9H18/c1-8-4-6-9(2,3)7-...  InChI=1S/C9H18/c1-8-5-4-6-9(2,3)...  InChI=1S/C9H20/c1-3-5-7-9-8-6-4-...  InChI=1S/C9H20/c1-8(2)6-7-9(3,4)...                                  NaN                                  NaN                                  NaN                                  NaN                                  NaN                                  NaN                                  NaN                                  NaN                                  NaN                                  NaN                                  NaN                                  NaN                                  NaN                                  NaN                                  NaN       0.006       0.002       0.003       0.005       0.001       0.035       0.012       0.009       0.020       0.006        0.003        0.001        0.002        0.005        0.084        0.001        0.012        0.002        0.054        0.040        0.047        0.022        0.055        0.008        0.006        0.027        0.028        0.012        0.027        0.008        0.004        0.001        0.001        0.017        0.002        0.025        0.010        0.010        0.001        0.005        0.006        0.090        0.018        0.013        0.030        0.009        0.019        0.006        0.040        0.018        0.016        0.003        0.007        0.008        0.006        0.003        0.007        0.002        0.033        0.006        0.004        0.004        0.002        0.002        0.014        0.015          NaN          NaN          NaN          NaN          NaN          NaN          NaN          NaN          NaN          NaN          NaN          NaN          NaN          NaN          NaN          NaN           NaN
```

## leenhouts_benchmark\datasets\datasets\fuel_ignition_numbers\processed_data\mon_pure_exp.csv
- rows: 332, cols: 3
- columns: ['value', 'unit', 'component_inchi_0']
```
   value unit                    component_inchi_0
0   82.0    -  InChI=1S/C10H12/c1-2-6-10-8-4-3-...
1   96.0    -  InChI=1S/C10H12/c1-2-9-7-4-5-8(6...
```

## leenhouts_benchmark\datasets\datasets\viscosity\processed_data\viscosity_mix_exp.csv
- rows: 35938, cols: 13
- columns: ['value', 'unit', 'fraction_type', 'component_inchi_0', 'component_inchi_1', 'component_inchi_2', 'component_inchi_3', 'fraction_0', 'fraction_1', 'fraction_2', 'fraction_3', 'temperature', 'temperature_unit']
```
      value       unit fraction_type                    component_inchi_0                    component_inchi_1  component_inchi_2  component_inchi_3  fraction_0  fraction_1  fraction_2  fraction_3  temperature temperature_unit
0  0.678602  ln(mPa*s)         molar  InChI=1S/C10H10O4/c1-13-9(11)7-5...  InChI=1S/C3H8O/c1-2-3-4/h4H,2-3H...                NaN                NaN       0.048       0.952         NaN         NaN        298.0                K
1  0.753922  ln(mPa*s)         molar  InChI=1S/C10H10O4/c1-13-9(11)7-5...  InChI=1S/C3H8O/c1-2-3-4/h4H,2-3H...                NaN                NaN       0.132       0.868         NaN         NaN        298.0                K
```

## leenhouts_benchmark\datasets\datasets\viscosity\processed_data\viscosity_mix_exp_with_ideal.csv
- rows: 35938, cols: 15
- columns: ['value', 'unit', 'fraction_type', 'component_inchi_0', 'component_inchi_1', 'component_inchi_2', 'component_inchi_3', 'fraction_0', 'fraction_1', 'fraction_2', 'fraction_3', 'temperature', 'temperature_unit', 'ideal_value', 'excess_value']
```
      value       unit fraction_type                    component_inchi_0                    component_inchi_1  component_inchi_2  component_inchi_3  fraction_0  fraction_1  fraction_2  fraction_3  temperature temperature_unit  ideal_value  excess_value
0  0.678602  ln(mPa*s)         molar  InChI=1S/C10H10O4/c1-13-9(11)7-5...  InChI=1S/C3H8O/c1-2-3-4/h4H,2-3H...                NaN                NaN       0.048       0.952         NaN         NaN        298.0                K     0.820004     -0.141402
1  0.753922  ln(mPa*s)         molar  InChI=1S/C10H10O4/c1-13-9(11)7-5...  InChI=1S/C3H8O/c1-2-3-4/h4H,2-3H...                NaN                NaN       0.132       0.868         NaN         NaN        298.0                K     0.978983     -0.225060
```

## leenhouts_benchmark\datasets\datasets\viscosity\processed_data\viscosity_pure_exp.csv
- rows: 3027, cols: 5
- columns: ['value', 'unit', 'component_inchi_0', 'temperature', 'temperature_unit']
```
      value       unit       component_inchi_0  temperature temperature_unit
0 -0.322592  ln(mPa*s)  InChI=1S/BBr3/c2-1(3)4        298.0                K
1 -0.025789  ln(mPa*s)       InChI=1S/Br2/c1-2        298.0                K
```

## leenhouts_benchmark\datasets\datasets\fuel_ignition_numbers\raw_data\processed_MON.csv
- rows: 684, cols: 7
- columns: ['value', 'error', 'Train_Test_Label', 'cmp_ids', 'cmp_mole_fractions', 'property', 'unit']
```
   value    error Train_Test_Label cmp_ids cmp_mole_fractions             property  unit
0  115.0  24.3025             test     [0]              [1.0]  Motor octane number   NaN
1    0.0  10.6660            train     [1]              [1.0]  Motor octane number   NaN
```

## leenhouts_benchmark\datasets\datasets\fuel_ignition_numbers\raw_data\published_MONdata.csv
- rows: 722, cols: 247
- columns: ['Label', 'value', 'pred_value', 'error', 'Train_Test_Label', 'cmp_0_smiles', 'cmp_1_smiles', 'cmp_2_smiles', 'cmp_3_smiles', 'cmp_4_smiles', 'cmp_5_smiles', 'cmp_6_smiles', 'cmp_7_smiles', 'cmp_8_smiles', 'cmp_9_smiles', 'cmp_10_smiles', 'cmp_11_smiles', 'cmp_12_smiles', 'cmp_13_smiles', 'cmp_14_smiles', 'cmp_15_smiles', 'cmp_16_smiles', 'cmp_17_smiles', 'cmp_18_smiles', 'cmp_19_smiles', 'cmp_20_smiles', 'cmp_21_smiles', 'cmp_22_smiles', 'cmp_23_smiles', 'cmp_24_smiles', 'cmp_25_smiles', 'cmp_26_smiles', 'cmp_27_smiles', 'cmp_28_smiles', 'cmp_29_smiles', 'cmp_30_smiles', 'cmp_31_smiles', 'cmp_32_smiles', 'cmp_33_smiles', 'cmp_34_smiles']
```
       Label  value  pred_value    error Train_Test_Label cmp_0_smiles  cmp_1_smiles  cmp_2_smiles  cmp_3_smiles  cmp_4_smiles  cmp_5_smiles  cmp_6_smiles  cmp_7_smiles  cmp_8_smiles  cmp_9_smiles  cmp_10_smiles  cmp_11_smiles  cmp_12_smiles  cmp_13_smiles  cmp_14_smiles  cmp_15_smiles  cmp_16_smiles  cmp_17_smiles  cmp_18_smiles  cmp_19_smiles  cmp_20_smiles  cmp_21_smiles  cmp_22_smiles  cmp_23_smiles  cmp_24_smiles  cmp_25_smiles  cmp_26_smiles  cmp_27_smiles  cmp_28_smiles  cmp_29_smiles  cmp_30_smiles  cmp_31_smiles  cmp_32_smiles  cmp_33_smiles  cmp_34_smiles  cmp_35_smiles  cmp_36_smiles  cmp_37_smiles  cmp_38_smiles  cmp_39_smiles  cmp_40_smiles  cmp_41_smiles  cmp_42_smiles  cmp_43_smiles  cmp_44_smiles  cmp_45_smiles  cmp_46_smiles  cmp_47_smiles  cmp_48_smiles  cmp_49_smiles  cmp_50_smiles  cmp_51_smiles  cmp_52_smiles  cmp_53_smiles  cmp_54_smiles  cmp_55_smiles  cmp_56_smiles  cmp_57_smiles  cmp_58_smiles  cmp_59_smiles  cmp_60_smiles  cmp_61_smiles  cmp_62_smiles  cmp_63_smiles  cmp_64_smiles  cmp_65_smiles  cmp_66_smiles  cmp_67_smiles  cmp_68_smiles  cmp_69_smiles  cmp_70_smiles  cmp_71_smiles  cmp_72_smiles  cmp_73_smiles  cmp_74_smiles  cmp_75_smiles  cmp_76_smiles  cmp_77_smiles  cmp_78_smiles  cmp_79_smiles  cmp_80_smiles  cmp_81_smiles  cmp_82_smiles  cmp_83_smiles  cmp_84_smiles  cmp_85_smiles  cmp_86_smiles  cmp_87_smiles  cmp_88_smiles  cmp_89_smiles  cmp_90_smiles  cmp_91_smiles  cmp_92_smiles  cmp_93_smiles  cmp_94_smiles  cmp_95_smiles  cmp_96_smiles  cmp_97_smiles  cmp_98_smiles  cmp_99_smiles  cmp_100_smiles  cmp_101_smiles  cmp_102_smiles  cmp_103_smiles  cmp_104_smiles  cmp_105_smiles  cmp_106_smiles  cmp_107_smiles  cmp_108_smiles  cmp_109_smiles  cmp_110_smiles  cmp_111_smiles  cmp_112_smiles  cmp_113_smiles  cmp_114_smiles  cmp_115_smiles  cmp_116_smiles  cmp_117_smiles  cmp_118_smiles  cmp_119_smiles  cmp_120_smiles  Mole fraction of cmp0  Mole fraction of cmp1  Mole fraction of cmp2  Mole fraction of cmp3  Mole fraction of cmp4  Mole fraction of cmp5  Mole fraction of cmp6  Mole fraction of cmp7  Mole fraction of cmp8  Mole fraction of cmp9  Mole fraction of cmp10  Mole fraction of cmp11  Mole fraction of cmp12  Mole fraction of cmp13  Mole fraction of cmp14  Mole fraction of cmp15  Mole fraction of cmp16  Mole fraction of cmp17  Mole fraction of cmp18  Mole fraction of cmp19  Mole fraction of cmp20  Mole fraction of cmp21  Mole fraction of cmp22  Mole fraction of cmp23  Mole fraction of cmp24  Mole fraction of cmp25  Mole fraction of cmp26  Mole fraction of cmp27  Mole fraction of cmp28  Mole fraction of cmp29  Mole fraction of cmp30  Mole fraction of cmp31  Mole fraction of cmp32  Mole fraction of cmp33  Mole fraction of cmp34  Mole fraction of cmp35  Mole fraction of cmp36  Mole fraction of cmp37  Mole fraction of cmp38  Mole fraction of cmp39  Mole fraction of cmp40  Mole fraction of cmp41  Mole fraction of cmp42  Mole fraction of cmp43  Mole fraction of cmp44  Mole fraction of cmp45  Mole fraction of cmp46  Mole fraction of cmp47  Mole fraction of cmp48  Mole fraction of cmp49  Mole fraction of cmp50  Mole fraction of cmp51  Mole fraction of cmp52  Mole fraction of cmp53  Mole fraction of cmp54  Mole fraction of cmp55  Mole fraction of cmp56  Mole fraction of cmp57  Mole fraction of cmp58  Mole fraction of cmp59  Mole fraction of cmp60  Mole fraction of cmp61  Mole fraction of cmp62  Mole fraction of cmp63  Mole fraction of cmp64  Mole fraction of cmp65  Mole fraction of cmp66  Mole fraction of cmp67  Mole fraction of cmp68  Mole fraction of cmp69  Mole fraction of cmp70  Mole fraction of cmp71  Mole fraction of cmp72  Mole fraction of cmp73  Mole fraction of cmp74  Mole fraction of cmp75  Mole fraction of cmp76  Mole fraction of cmp77  Mole fraction of cmp78  Mole fraction of cmp79  Mole fraction of cmp80  Mole fraction of cmp81  Mole fraction of cmp82  Mole fraction of cmp83  Mole fraction of cmp84  Mole fraction of cmp85  Mole fraction of cmp86  Mole fraction of cmp87  Mole fraction of cmp88  Mole fraction of cmp89  Mole fraction of cmp90  Mole fraction of cmp91  Mole fraction of cmp92  Mole fraction of cmp93  Mole fraction of cmp94  Mole fraction of cmp95  Mole fraction of cmp96  Mole fraction of cmp97  Mole fraction of cmp98  Mole fraction of cmp99  Mole fraction of cmp100  Mole fraction of cmp101  Mole fraction of cmp102  Mole fraction of cmp103  Mole fraction of cmp104  Mole fraction of cmp105  Mole fraction of cmp106  Mole fraction of cmp107  Mole fraction of cmp108  Mole fraction of cmp109  Mole fraction of cmp110  Mole fraction of cmp111  Mole fraction of cmp112  Mole fraction of cmp113  Mole fraction of cmp114  Mole fraction of cmp115  Mole fraction of cmp116  Mole fraction of cmp117  Mole fraction of cmp118  Mole fraction of cmp119  Mole fraction of cmp120
0    BENZENE    115     91.8979  24.3025             test     c1ccccc1           NaN           NaN           NaN           NaN           NaN           NaN           NaN           NaN           NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN             NaN             NaN             NaN             NaN             NaN             NaN             NaN             NaN             NaN             NaN             NaN             NaN             NaN             NaN             NaN             NaN             NaN             NaN             NaN             NaN             NaN                    100                    NaN                    NaN                    NaN                    NaN                    NaN                    NaN                    NaN                    NaN                    NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                      NaN                      NaN                      NaN                      NaN                      NaN                      NaN                      NaN                      NaN                      NaN                      NaN                      NaN                      NaN                      NaN                      NaN                      NaN                      NaN                      NaN                      NaN                      NaN                      NaN                      NaN
1  N-HEPTANE      0     11.4845  10.6660            train      CCCCCCC           NaN           NaN           NaN           NaN           NaN           NaN           NaN           NaN           NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN            NaN             NaN             NaN             NaN             NaN             NaN             NaN             NaN             NaN             NaN             NaN             NaN             NaN             NaN             NaN             NaN             NaN             NaN             NaN             NaN             NaN             NaN                    100                    NaN                    NaN                    NaN                    NaN                    NaN                    NaN                    NaN                    NaN                    NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                     NaN                      NaN                      NaN                      NaN                      NaN                      NaN                      NaN                      NaN                      NaN                      NaN                      NaN                      NaN                      NaN                      NaN                      NaN                      NaN                      NaN                      NaN                      NaN                      NaN                      NaN                      NaN
```

## bilodeau_nist_viscosity\pretrained_models\pretrained_models\nist_dippr_source\NIST_Visc_Data.csv
- rows: 239200, cols: 10
- columns: ['ID_1', 'ID_2', 'MolFrac_1', 'T', 'P', 'Visc', 'Visc_Unc', 'Ref_ID', 'MOL_1', 'MOL_2']
```
          ID_1         ID_2  MolFrac_1       T      P      Visc  Visc_Unc   Ref_ID                    MOL_1         MOL_2
0  trc4mit_413  trc4mit_473        0.5  298.15  101.0  0.001449  0.000014  ref4409  O=[N+]([O-])c1cccc(O)c1  CCCCCOC(C)=O
1  trc4mit_609  trc4mit_473        0.5  298.15  101.0  0.001051  0.000010  ref4409    O=[N+]([O-])c1ccccc1O  CCCCCOC(C)=O
```

## leenhouts_benchmark\datasets\datasets\flashpoint\rejected_data\flashpoint_mix_exp_rejected.csv
- rows: 0, cols: 11
- columns: ['source_sheet', 'row_index', 'reason', 'raw_target', 'raw_fuel1_inchi', 'raw_fuel2_inchi', 'raw_fuel3_inchi', 'raw_fuel4_inchi', 'raw_molar_fraction_fuel_1', 'raw_molar_fraction_fuel_2', 'raw_molar_fraction_fuel_3']
```
Empty DataFrame
Columns: [source_sheet, row_index, reason, raw_target, raw_fuel1_inchi, raw_fuel2_inchi, raw_fuel3_inchi, raw_fuel4_inchi, raw_molar_fraction_fuel_1, raw_molar_fraction_fuel_2, raw_molar_fraction_fuel_3]
Index: []
```

## leenhouts_benchmark\datasets\datasets\flashpoint\rejected_data\flashpoint_pure_exp_rejected.csv
- rows: 0, cols: 5
- columns: ['source_sheet', 'row_index', 'raw_component_inchi_0', 'raw_target', 'reason']
```
Empty DataFrame
Columns: [source_sheet, row_index, raw_component_inchi_0, raw_target, reason]
Index: []
```

## leenhouts_benchmark\datasets\datasets\fuel_ignition_numbers\rejected_data\dcn_mix_exp_rejected.csv
- rows: 34, cols: 11
- columns: ['source_sheet', 'row_index', 'reason', 'raw_target', 'raw_fuel1_inchi', 'raw_fuel2_inchi', 'raw_fuel3_inchi', 'raw_fuel4_inchi', 'raw_molar_fraction_fuel_1', 'raw_molar_fraction_fuel_2', 'raw_molar_fraction_fuel_3']
```
   source_sheet  row_index             reason  raw_target                      raw_fuel1_inchi                      raw_fuel2_inchi                      raw_fuel3_inchi  raw_fuel4_inchi  raw_molar_fraction_fuel_1  raw_molar_fraction_fuel_2  raw_molar_fraction_fuel_3
0  DCN_training        286  missing_fractions       23.23  InChI=1S/C7H16/c1-3-5-7-6-4-2/h3...  InChI=1S/C8H18/c1-7(2)6-8(3,4)5/...  InChI=1S/C7H8/c1-7-5-3-2-4-6-7/h...              NaN                   0.101237                        NaN                        NaN
1  DCN_training        287  missing_fractions       21.96  InChI=1S/C7H16/c1-3-5-7-6-4-2/h3...  InChI=1S/C8H18/c1-7(2)6-8(3,4)5/...  InChI=1S/C9H12/c1-7-4-5-8(2)9(3)...              NaN                   0.102000                        NaN                        NaN
```

## leenhouts_benchmark\datasets\datasets\fuel_ignition_numbers\rejected_data\dcn_pure_exp_rejected.csv
- rows: 0, cols: 5
- columns: ['source_sheet', 'row_index', 'raw_component_inchi_0', 'raw_target', 'reason']
```
Empty DataFrame
Columns: [source_sheet, row_index, raw_component_inchi_0, raw_target, reason]
Index: []
```

## leenhouts_benchmark\datasets\datasets\fuel_ignition_numbers\rejected_data\mon_mix_exp_rejected.csv
- rows: 56, cols: 6
- columns: ['row_index', 'reason', 'raw_target', 'split', 'component_index', 'raw_identifier']
```
   row_index                reason  raw_target  split  component_index raw_identifier
0        366  fraction_sum_not_one        86.6  train                0           CCCC
1        368  fraction_sum_not_one        87.1   test                0           CCCC
```

## leenhouts_benchmark\datasets\datasets\fuel_ignition_numbers\rejected_data\mon_pure_exp_rejected.csv
- rows: 1, cols: 6
- columns: ['row_index', 'reason', 'raw_target', 'split', 'component_index', 'raw_identifier']
```
   row_index                               reason  raw_target split  component_index     raw_identifier
0        175  invalid_component_identifier:con...        97.0  test                0  CC(C)CCCC([O-])=O
```

## leenhouts_benchmark\datasets\datasets\viscosity\rejected_data\viscosity_mix_exp_rejected.csv
- rows: 30, cols: 14
- columns: ['dataset', 'row_index', 'reason', 'raw_target', 'raw_fuel1_inchi', 'raw_fuel2_inchi', 'raw_fuel3_inchi', 'raw_fuel4_inchi', 'raw_smiles_0', 'raw_smiles_1', 'raw_comp_0', 'raw_comp_1', 'raw_logV', 'raw_temperature']
```
              dataset  row_index                               reason  raw_target                      raw_fuel1_inchi                      raw_fuel2_inchi  raw_fuel3_inchi  raw_fuel4_inchi  raw_smiles_0 raw_smiles_1  raw_comp_0  raw_comp_1  raw_logV  raw_temperature
0  Viscosity_training       4190                 invalid_fraction_sum      0.7178  InChI=1S/C8H8/c1-2-8-6-4-3-5-7-8...  InChI=1S/C8H10/c1-7-5-3-4-6-8(7)...              NaN              NaN           NaN          NaN         NaN         NaN       NaN              NaN
1           NIST_logV      33562  invalid_component_identifier:0:c...         NaN                                  NaN                                  NaN              NaN              NaN  Cl[As](Cl)Cl        CCOCC         0.1         0.9   -0.5505           303.15
```

## leenhouts_benchmark\datasets\datasets\viscosity\rejected_data\viscosity_pure_exp_rejected.csv
- rows: 2, cols: 9
- columns: ['dataset', 'row_index', 'reason', 'raw_smiles_0', 'raw_smiles_1', 'raw_comp_0', 'raw_comp_1', 'raw_logV', 'raw_temperature']
```
     dataset  row_index                               reason              raw_smiles_0  raw_smiles_1  raw_comp_0  raw_comp_1  raw_logV  raw_temperature
0  NIST_logV       4805  invalid_component_identifier:0:c...  CC(C)C[Al](CC(C)C)CC(C)C           NaN         1.0         0.0    0.3491            298.0
1  NIST_logV       4806  invalid_component_identifier:0:c...      CC(C)C[Al](Cl)CC(C)C           NaN         1.0         0.0    0.6153            298.0
```

## leenhouts_benchmark\datasets\datasets\solubility\processed_data\solubility_mix_exp.csv
- rows: 125932, cols: 10
- columns: ['value', 'unit', 'fraction_type', 'solute_inchi', 'component_inchi_0', 'component_inchi_1', 'fraction_0', 'fraction_1', 'temperature', 'temperature_unit']
```
      value unit fraction_type                         solute_inchi                  component_inchi_0  component_inchi_1  fraction_0  fraction_1  temperature temperature_unit
0 -3.256490    -         molar  InChI=1S/C10H10N2O/c1-8-7-10(13)...  InChI=1S/C2H6O/c1-2-3/h3H,2H2,1H3  InChI=1S/H2O/h1H2         0.1         0.9       283.15           Kelvin
1 -3.127844    -         molar  InChI=1S/C10H10N2O/c1-8-7-10(13)...  InChI=1S/C2H6O/c1-2-3/h3H,2H2,1H3  InChI=1S/H2O/h1H2         0.1         0.9       293.15           Kelvin
```

## leenhouts_benchmark\datasets\datasets\solubility\processed_data\solubility_mix_exp_with_ideal.csv
- rows: 125932, cols: 12
- columns: ['value', 'unit', 'fraction_type', 'solute_inchi', 'component_inchi_0', 'component_inchi_1', 'fraction_0', 'fraction_1', 'temperature', 'temperature_unit', 'ideal_value', 'excess_value']
```
      value unit fraction_type                         solute_inchi                  component_inchi_0  component_inchi_1  fraction_0  fraction_1  temperature temperature_unit  ideal_value  excess_value
0 -3.256490    -         molar  InChI=1S/C10H10N2O/c1-8-7-10(13)...  InChI=1S/C2H6O/c1-2-3/h3H,2H2,1H3  InChI=1S/H2O/h1H2         0.1         0.9       283.15           Kelvin    -3.605601      0.349111
1 -3.127844    -         molar  InChI=1S/C10H10N2O/c1-8-7-10(13)...  InChI=1S/C2H6O/c1-2-3/h3H,2H2,1H3  InChI=1S/H2O/h1H2         0.1         0.9       293.15           Kelvin    -3.568484      0.440640
```

## leenhouts_benchmark\datasets\datasets\solubility\processed_data\solubility_pure_exp.csv
- rows: 101564, cols: 6
- columns: ['value', 'unit', 'solute_inchi', 'component_inchi_0', 'temperature', 'temperature_unit']
```
      value unit                         solute_inchi                  component_inchi_0  temperature temperature_unit
0 -3.772370    -  InChI=1S/C10H10ClN3O2/c1-15-7-3-...  InChI=1S/C2H6O/c1-2-3/h3H,2H2,1H3       273.15           Kelvin
1 -3.686977    -  InChI=1S/C10H10ClN3O2/c1-15-7-3-...  InChI=1S/C2H6O/c1-2-3/h3H,2H2,1H3       278.15           Kelvin
```

## leenhouts_benchmark\datasets\datasets\solvation_free_energy\processed_data\bucket_transition_audit.csv
- rows: 1, cols: 7
- columns: ['dataset', 'raw_rows_with_target', 'raw_pure_candidates_by_frac_rule', 'raw_mix_candidates_by_frac_rule', 'final_pure_bucket_source_observations', 'final_mix_bucket_source_observations', 'moved_from_mix_to_pure_after_standardization']
```
        dataset  raw_rows_with_target  raw_pure_candidates_by_frac_rule  raw_mix_candidates_by_frac_rule  final_pure_bucket_source_observations  final_mix_bucket_source_observations  moved_from_mix_to_pure_after_standardization
0  MixSolvGH-QM               1000000                            537589                           462411                               577331                                 422669                                 39742         
```

## leenhouts_benchmark\datasets\datasets\solvation_free_energy\processed_data\gsolv_mix_comp.csv
- rows: 422669, cols: 14
- columns: ['value', 'unit', 'fraction_type', 'solute_inchi', 'component_inchi_0', 'component_inchi_1', 'component_inchi_2', 'component_inchi_3', 'fraction_0', 'fraction_1', 'fraction_2', 'fraction_3', 'temperature', 'temperature_unit']
```
      value      unit fraction_type            solute_inchi                 component_inchi_0                    component_inchi_1  component_inchi_2  component_inchi_3  fraction_0  fraction_1  fraction_2  fraction_3  temperature temperature_unit
0 -4.607036  kcal/mol         molar  InChI=1S/BBr3/c2-1(3)4        InChI=1S/C2H3N/c1-2-3/h1H3  InChI=1S/C4H8O/c1-3-4(2)5/h3H2,1...                NaN                NaN         0.8         0.2         NaN         NaN          NaN           Kelvin
1 -4.879030  kcal/mol         molar  InChI=1S/BBr3/c2-1(3)4  InChI=1S/C2H4Cl2/c3-1-2-4/h1-2H2  InChI=1S/C4H8O/c1-3-4(2)5/h3H2,1...                NaN                NaN         0.4         0.6         NaN         NaN          NaN           Kelvin
```

## leenhouts_benchmark\datasets\datasets\solvation_free_energy\processed_data\gsolv_mix_comp_with_ideal.csv
- rows: 422669, cols: 16
- columns: ['value', 'unit', 'fraction_type', 'solute_inchi', 'component_inchi_0', 'component_inchi_1', 'component_inchi_2', 'component_inchi_3', 'fraction_0', 'fraction_1', 'fraction_2', 'fraction_3', 'temperature', 'temperature_unit', 'ideal_value', 'excess_value']
```
      value      unit fraction_type            solute_inchi                 component_inchi_0                    component_inchi_1  component_inchi_2  component_inchi_3  fraction_0  fraction_1  fraction_2  fraction_3  temperature temperature_unit  ideal_value  excess_value
0 -4.607036  kcal/mol         molar  InChI=1S/BBr3/c2-1(3)4        InChI=1S/C2H3N/c1-2-3/h1H3  InChI=1S/C4H8O/c1-3-4(2)5/h3H2,1...                NaN                NaN         0.8         0.2         NaN         NaN          NaN           Kelvin          NaN           NaN
1 -4.879030  kcal/mol         molar  InChI=1S/BBr3/c2-1(3)4  InChI=1S/C2H4Cl2/c3-1-2-4/h1-2H2  InChI=1S/C4H8O/c1-3-4(2)5/h3H2,1...                NaN                NaN         0.4         0.6         NaN         NaN          NaN           Kelvin          NaN           NaN
```

## leenhouts_benchmark\datasets\datasets\solvation_free_energy\processed_data\gsolv_pure_comp.csv
- rows: 512846, cols: 6
- columns: ['value', 'unit', 'solute_inchi', 'component_inchi_0', 'temperature', 'temperature_unit']
```
      value      unit            solute_inchi                    component_inchi_0  temperature temperature_unit
0 -4.855748  kcal/mol  InChI=1S/BBr3/c2-1(3)4  InChI=1S/C10H22O/c1-2-3-4-5-6-7-...          NaN           Kelvin
1 -4.982608  kcal/mol  InChI=1S/BBr3/c2-1(3)4  InChI=1S/C14H14O/c1-3-7-13(8-4-1...          NaN           Kelvin
```

## leenhouts_benchmark\datasets\datasets\solvation_free_energy\processed_data\standardization_audit.csv
- rows: 3, cols: 6
- columns: ['output_file', 'source_observations', 'accepted_pre_dedup', 'processed_rows', 'rejected_rows', 'collapsed_by_dedup']
```
           output_file  source_observations  accepted_pre_dedup  processed_rows  rejected_rows  collapsed_by_dedup
0    gsolv_mix_exp.csv                64165               64091           63133             74                 958
1  gsolv_pure_comp.csv               577331              574597          512846           2734               61751
```

## leenhouts_benchmark\datasets\datasets\vap_enthalpy\processed_data\enthalpy_vap_mix_comp.csv
- rows: 30061, cols: 13
- columns: ['value', 'unit', 'fraction_type', 'component_inchi_0', 'component_inchi_1', 'component_inchi_2', 'component_inchi_3', 'component_inchi_4', 'fraction_0', 'fraction_1', 'fraction_2', 'fraction_3', 'fraction_4']
```
       value      unit fraction_type                    component_inchi_0                    component_inchi_1                    component_inchi_2               component_inchi_3                    component_inchi_4  fraction_0  fraction_1  fraction_2  fraction_3  fraction_4
0  11.060940  kcal/mol         molar  InChI=1S/C10H12O2/c1-2-12-10(11)...  InChI=1S/C10H23N/c1-3-5-7-9-11-1...  InChI=1S/C2H5ClO/c3-1-2-4/h4H,1-2H2  InChI=1S/C3H6O/c1-3(2)4/h1-2H3  InChI=1S/C5H10O/c1-4(2)5(3)6/h4H...         0.2         0.2         0.2         0.2         0.2
1  12.170966  kcal/mol         molar  InChI=1S/C10H12O2/c1-2-12-10(11)...  InChI=1S/C10H23N/c1-3-5-7-9-11-1...  InChI=1S/C2H5ClO/c3-1-2-4/h4H,1-2H2  InChI=1S/C3H6O/c1-3(2)4/h1-2H3  InChI=1S/C6H15O4P/c1-4-8-11(7,9-...         0.2         0.2         0.2         0.2         0.2
```

## leenhouts_benchmark\datasets\datasets\vap_enthalpy\processed_data\enthalpy_vap_mix_comp_with_ideal.csv
- rows: 30061, cols: 15
- columns: ['value', 'unit', 'fraction_type', 'component_inchi_0', 'component_inchi_1', 'component_inchi_2', 'component_inchi_3', 'component_inchi_4', 'fraction_0', 'fraction_1', 'fraction_2', 'fraction_3', 'fraction_4', 'ideal_value', 'excess_value']
```
       value      unit fraction_type                    component_inchi_0                    component_inchi_1                    component_inchi_2               component_inchi_3                    component_inchi_4  fraction_0  fraction_1  fraction_2  fraction_3  fraction_4  ideal_value  excess_value
0  11.060940  kcal/mol         molar  InChI=1S/C10H12O2/c1-2-12-10(11)...  InChI=1S/C10H23N/c1-3-5-7-9-11-1...  InChI=1S/C2H5ClO/c3-1-2-4/h4H,1-2H2  InChI=1S/C3H6O/c1-3(2)4/h1-2H3  InChI=1S/C5H10O/c1-4(2)5(3)6/h4H...         0.2         0.2         0.2         0.2         0.2    12.078451      -1.01751
1  12.170966  kcal/mol         molar  InChI=1S/C10H12O2/c1-2-12-10(11)...  InChI=1S/C10H23N/c1-3-5-7-9-11-1...  InChI=1S/C2H5ClO/c3-1-2-4/h4H,1-2H2  InChI=1S/C3H6O/c1-3(2)4/h1-2H3  InChI=1S/C6H15O4P/c1-4-8-11(7,9-...         0.2         0.2         0.2         0.2         0.2    13.476276      -1.30531
```

## leenhouts_benchmark\datasets\datasets\vap_enthalpy\processed_data\enthalpy_vap_pure_comp.csv
- rows: 81, cols: 3
- columns: ['value', 'unit', 'component_inchi_0']
```
       value      unit                    component_inchi_0
0  16.918044  kcal/mol  InChI=1S/C10H12O2/c1-2-12-10(11)...
1  14.544716  kcal/mol  InChI=1S/C10H22S/c1-9(2)5-7-11-8...
```

## leenhouts_benchmark\datasets\datasets\viscosity\processed_data\nist_vis_combined.csv
- rows: 34343, cols: 14
- columns: ['row_index', 'label', 'split', 'temperature', 'temperature_unit', 'logV', 'value', 'unit', 'component_inchi_0', 'component_inchi_1', 'fraction_0', 'fraction_1', 'compound_id_0', 'compound_id_1']
```
   row_index  label  split  temperature temperature_unit    logV     value       unit       component_inchi_0  component_inchi_1  fraction_0  fraction_1  compound_id_0  compound_id_1
0          0      0  train        298.0                K -0.1401 -0.322592  ln(mPa*s)  InChI=1S/BBr3/c2-1(3)4                NaN         1.0         NaN            NaN            NaN
1          1      1  train        298.0                K -0.0112 -0.025789  ln(mPa*s)       InChI=1S/Br2/c1-2                NaN         1.0         NaN            NaN            NaN
```

## leenhouts_benchmark\datasets\datasets\viscosity\processed_data\nist_vis_compounds_with_inchi.csv
- rows: 1645, cols: 5
- columns: ['row_index', 'compound_id', 'raw_smiles', 'component_inchi', 'reason']
```
   row_index  compound_id               raw_smiles                      component_inchi  reason
0          0            0  O=[N+]([O-])c1cccc(O)c1  InChI=1S/C6H5NO3/c8-6-3-1-2-5(4-...     NaN
1          1            1             CCCCCOC(C)=O  InChI=1S/C7H14O2/c1-3-4-5-6-9-7(...     NaN
```

## leenhouts_benchmark\datasets\datasets\flashpoint\raw_data\DatasetsFuelProperties.xlsx
- rows: 50000, cols: 9
- sheets: ['Viscosity synthetic', 'Viscosity_training', 'Viscosity_test', 'Flashpoint synthetic', 'Flashpoint_training', 'Flashpoint_test', 'DCN synthetic', 'DCN_training', 'DCN_test']
- columns: ['Unnamed: 0', 'fuel1 inchi', 'fuel2 inchi', 'fuel3 inchi', 'fuel4 inchi', 'molar fraction fuel 1', 'molar fraction fuel 2', 'molar fraction fuel 3', 'Synthetic value']
```
   Unnamed: 0                          fuel1 inchi                          fuel2 inchi                          fuel3 inchi                          fuel4 inchi  molar fraction fuel 1  molar fraction fuel 2  molar fraction fuel 3  Synthetic value
0           0  InChI=1S/C6H14O/c1-6(2,3)4-5-7/h...  InChI=1S/C8H16O/c1-2-3-5-8-6-4-7...                                  NaN                                  NaN               0.487805                    NaN                    NaN             2.33
1           1  InChI=1S/C9H20/c1-5-9(6-2)7-8(3)...  InChI=1S/C5H12O/c1-4(2)5(3)6/h4-...  InChI=1S/C10H12/c1-3-9-5-7-10(4-...  InChI=1S/C5H10O2/c1-3-5(6)7-4-2/...               0.564706               0.070588               0.070588             0.72
```

## leenhouts_benchmark\datasets\datasets\flashpoint\raw_data\PureFuels.xlsx
- rows: 263, cols: 3
- sheets: ['Viscosity', 'Flashpoint', 'DCN']
- columns: ['Unnamed: 0', 'InChI', 'Viscosity [mPa*s]']
```
   Unnamed: 0                            InChI  Viscosity [mPa*s]
0           0        InChI=1S/C2H6/c1-2/h1-2H3             0.0094
1           1  InChI=1S/C3H8/c1-3-2/h3H2,1-2H3             0.0083
```

## leenhouts_benchmark\datasets\datasets\fuel_ignition_numbers\raw_data\DatasetsFuelProperties.xlsx
- rows: 50000, cols: 9
- sheets: ['Viscosity synthetic', 'Viscosity_training', 'Viscosity_test', 'Flashpoint synthetic', 'Flashpoint_training', 'Flashpoint_test', 'DCN synthetic', 'DCN_training', 'DCN_test']
- columns: ['Unnamed: 0', 'fuel1 inchi', 'fuel2 inchi', 'fuel3 inchi', 'fuel4 inchi', 'molar fraction fuel 1', 'molar fraction fuel 2', 'molar fraction fuel 3', 'Synthetic value']
```
   Unnamed: 0                          fuel1 inchi                          fuel2 inchi                          fuel3 inchi                          fuel4 inchi  molar fraction fuel 1  molar fraction fuel 2  molar fraction fuel 3  Synthetic value
0           0  InChI=1S/C6H14O/c1-6(2,3)4-5-7/h...  InChI=1S/C8H16O/c1-2-3-5-8-6-4-7...                                  NaN                                  NaN               0.487805                    NaN                    NaN             2.33
1           1  InChI=1S/C9H20/c1-5-9(6-2)7-8(3)...  InChI=1S/C5H12O/c1-4(2)5(3)6/h4-...  InChI=1S/C10H12/c1-3-9-5-7-10(4-...  InChI=1S/C5H10O2/c1-3-5(6)7-4-2/...               0.564706               0.070588               0.070588             0.72
```

## leenhouts_benchmark\datasets\datasets\fuel_ignition_numbers\raw_data\PureFuels.xlsx
- rows: 263, cols: 3
- sheets: ['Viscosity', 'Flashpoint', 'DCN']
- columns: ['Unnamed: 0', 'InChI', 'Viscosity [mPa*s]']
```
   Unnamed: 0                            InChI  Viscosity [mPa*s]
0           0        InChI=1S/C2H6/c1-2/h1-2H3             0.0094
1           1  InChI=1S/C3H8/c1-3-2/h3H2,1-2H3             0.0083
```

## leenhouts_benchmark\datasets\datasets\solubility\raw_data\BigSolDBv2_1.csv
- rows: 112465, cols: 12
- columns: ['SMILES_Solute', 'Temperature_K', 'Solvent', 'SMILES_Solvent', 'Solubility(mole_fraction)', 'Solubility(mol/L)', 'LogS(mol/L)', 'Compound_Name', 'CAS', 'PubChem_CID', 'FDA_Approved', 'Source']
```
                  SMILES_Solute  Temperature_K  Solvent SMILES_Solvent  Solubility(mole_fraction)  Solubility(mol/L)  LogS(mol/L)                 Compound_Name         CAS  PubChem_CID FDA_Approved              Source
0  CCCCCCCCCCCCCCCCCCCC(=O)OCCO         311.25  ethanol            CCO                     0.0006           0.010083    -1.996419  Ethylene glycol monoeicosate  26158-80-5       538813           No  10.1007/bf00649573
1  CCCCCCCCCCCCCCCCCCCC(=O)OCCO         314.65  ethanol            CCO                     0.0012           0.020100    -1.696799  Ethylene glycol monoeicosate  26158-80-5       538813           No  10.1007/bf00649573
```

## leenhouts_benchmark\datasets\datasets\solubility\raw_data\MixtureSolDB.csv
- rows: 175378, cols: 17
- columns: ['SMILES_Solute', 'Temperature_K', 'Solubility(mole_fraction)', 'LogS(mole_fraction)', 'Solubility(g/g100)', 'LogS(g/g100)', 'Solvent1', 'Solvent2', 'SMILES_Solvent1', 'SMILES_Solvent2', 'Fraction_Solvent1', 'Fraction_Type', 'Compound_Name', 'CAS', 'PubChem_CID', 'FDA_Approved', 'Source']
```
                         SMILES_Solute  Temperature_K  Solubility(mole_fraction)  LogS(mole_fraction)  Solubility(g/g100)  LogS(g/g100)      Solvent1 Solvent2 SMILES_Solvent1 SMILES_Solvent2  Fraction_Solvent1 Fraction_Type          Compound_Name          CAS  PubChem_CID FDA_Approved                     Source
0  CCN(C)C(=O)Oc1cccc([C@H](C)N(C)C...         278.15                     0.0872            -1.059484          212.339615      2.327031  acetonitrile    water            CC#N               O                0.0          mole  Rivastigmine tartrate  129101-54-8    6918078.0          Yes  10.1007/s10973-018-7684-y
1  CCN(C)C(=O)Oc1cccc([C@H](C)N(C)C...         283.15                     0.0983            -1.007446          242.315737      2.384382  acetonitrile    water            CC#N               O                0.0          mole  Rivastigmine tartrate  129101-54-8    6918078.0          Yes  10.1007/s10973-018-7684-y
```

## leenhouts_benchmark\datasets\datasets\solvation_free_energy\raw_data\MixSolvGH-QM.csv
- rows: 1000000, cols: 6
- columns: ['Gsolv (kcal/mol)', 'Hsolv (kcal/mol)', 'inchi_solute', 'inchi_solvent1', 'frac_solvent1', 'inchi_solvent2']
```
   Gsolv (kcal/mol)  Hsolv (kcal/mol)                         inchi_solute                       inchi_solvent1  frac_solvent1                       inchi_solvent2
0         -6.422754        -10.647176  InChI=1/C6H10O/c1-5(7)6-3-2-4-6/...  InChI=1/C2H4O2/c1-2(3)4/h1H3,(H,...            1.0  InChI=1/C7H8/c1-7-5-3-2-4-6-7/h2...
1        -11.531859        -18.975067  InChI=1/C18H30O2/c1-15(2)8-5-9-1...  InChI=1/C6F6/c7-1-2(8)4(10)6(12)...            NaN                                  NaN
```

## leenhouts_benchmark\datasets\datasets\vap_enthalpy\raw_data\MiscibleSolventData.csv
- rows: 30142, cols: 19
- columns: ['ID', 'SMILES_0', 'SMILES_1', 'SMILES_2', 'SMILES_3', 'SMILES_4', 'comp_0', 'comp_1', 'comp_2', 'comp_3', 'comp_4', 'label', 'num_components', 'density_grams_per_cubic_meter', 'heat_of_vaporization_kcal_per_mol', 'enthalpy_of_mixing_kJ_per_mol', 'Simulation_number_of_atoms', 'Simulation_number_of_molecules', 'Simulation_volume']
```
   ID          SMILES_0  SMILES_1  SMILES_2  SMILES_3  SMILES_4  comp_0  comp_1  comp_2  comp_3  comp_4                 label  num_components  density_grams_per_cubic_meter  heat_of_vaporization_kcal_per_mol  enthalpy_of_mixing_kJ_per_mol  Simulation_number_of_atoms  Simulation_number_of_molecules  Simulation_volume
0   0  O=C/C=C/c1ccccc1       NaN       NaN       NaN       NaN   100.0     NaN     NaN     NaN     NaN  trans-Cinnamaldehyde               1                       1.055103                          16.888887                            0.0                      9990.0                           555.0         115442.529
1   1    CC(=O)OCCC(C)C       NaN       NaN       NaN       NaN   100.0     NaN     NaN     NaN     NaN     Isopentyl acetate               1                       0.892063                          11.751006                            0.0                      9982.0                           434.0         105177.383
```

## leenhouts_benchmark\datasets\datasets\viscosity\raw_data\nist_vis\compounds.csv
- rows: 1645, cols: 2
- columns: ['compound_id', 'smiles']
```
   compound_id                   smiles
0            0  O=[N+]([O-])c1cccc(O)c1
1            1             CCCCCOC(C)=O
```

## leenhouts_benchmark\datasets\datasets\viscosity\raw_data\nist_vis\nist_vis\processed_NISTlogV.csv
- rows: 239200, cols: 9
- columns: ['T', 'P', 'value', 'Visc_Unc', 'Ref_ID', 'cmp_ids', 'cmp_mole_fractions', 'property', 'unit']
```
        T      P     value  Visc_Unc   Ref_ID cmp_ids cmp_mole_fractions       property unit
0  298.15  101.0 -6.536882  0.000014  ref4409  [0, 1]         [0.5, 0.5]  Log viscosity   cP
1  298.15  101.0 -6.858013  0.000010  ref4409  [2, 1]         [0.5, 0.5]  Log viscosity   cP
```

## leenhouts_benchmark\datasets\datasets\viscosity\raw_data\nist_vis\nist_vis_combined.csv
- rows: 34366, cols: 14
- columns: ['row_index', 'label', 'split', 'temperature', 'temperature_unit', 'logV', 'target', 'unit', 'component_inchi_0', 'component_inchi_1', 'fraction_0', 'fraction_1', 'compound_id_0', 'compound_id_1']
```
   row_index  label  split  temperature temperature_unit    logV    target   unit       component_inchi_0  component_inchi_1  fraction_0  fraction_1  compound_id_0  compound_id_1
0          0      0  train        298.0                K -0.1401  0.724269  mPa*s  InChI=1S/BBr3/c2-1(3)4                NaN         1.0         NaN            NaN            NaN
1          1      1  train        298.0                K -0.0112  0.974541  mPa*s       InChI=1S/Br2/c1-2                NaN         1.0         NaN            NaN            NaN
```

## leenhouts_benchmark\datasets\datasets\viscosity\raw_data\nist_vis\nist_vis_compounds_with_inchi.csv
- rows: 1645, cols: 5
- columns: ['row_index', 'compound_id', 'raw_smiles', 'component_inchi', 'reason']
```
   row_index  compound_id               raw_smiles                      component_inchi  reason
0          0            0  O=[N+]([O-])c1cccc(O)c1  InChI=1S/C6H5NO3/c8-6-3-1-2-5(4-...     NaN
1          1            1             CCCCCOC(C)=O  InChI=1S/C7H14O2/c1-3-4-5-6-9-7(...     NaN
```

## leenhouts_benchmark\datasets\datasets\viscosity\raw_data\nist_vis\published_logV.csv
- rows: 34374, cols: 10
- columns: ['Label', 'logV', 'T', 'Predict logV', 'Predict uncertainty logV', 'Train_Test_Label', 'SMILES_0', 'SMILES_1', 'comp_0', 'comp_1']
```
   Label    logV      T  Predict logV  Predict uncertainty logV Train_Test_Label     SMILES_0 SMILES_1  comp_0  comp_1
0      0 -0.1401  298.0       -0.1371                    0.0625            train  B(Br)(Br)Br      NaN     1.0     0.0
1      1 -0.0112  298.0       -0.0275                    0.0750            train         BrBr      NaN     1.0     0.0
```

## bilodeau_nist_viscosity\pretrained_models\pretrained_models\bp_data\bp_pred.csv
- rows: 3065, cols: 2
- columns: ['SMILES', 'BP']
```
           SMILES          BP
0  c1(C)c(N)cccc1  197.131703
1       O=C1CCCN1  239.880588
```

## bilodeau_nist_viscosity\pretrained_models\pretrained_models\mp_data\mp_pred.csv
- rows: 3065, cols: 2
- columns: ['SMILES', 'MP']
```
           SMILES          MP
0  c1(C)c(N)cccc1  298.753515
1       O=C1CCCN1  317.854910
```

## bilodeau_nist_viscosity\pretrained_models\pretrained_models\nist_dippr_data\data.csv
- rows: 35128, cols: 3
- columns: ['MOL_1', 'MOL_2', 'logV']
```
         MOL_1 MOL_2      logV
0  B(Br)(Br)Br   CCO -0.140112
1  B(Br)(Br)Br   CCO       NaN
```

## bilodeau_nist_viscosity\pretrained_models\pretrained_models\nist_dippr_data\data_features.csv
- rows: 35128, cols: 2
- columns: ['MolFrac_1', 'T']
```
   MolFrac_1      T
0        1.0  298.0
1        1.1  298.0
```

## bilodeau_nist_viscosity\pretrained_models\pretrained_models\nist_dippr_data\test.csv
- rows: 6798, cols: 3
- columns: ['MOL_1', 'MOL_2', 'logV']
```
       MOL_1     MOL_2      logV
0  BrC(Br)Br  CCC(C)=O -0.394850
1  BrC(Br)Br  CCC(C)=O -0.321717
```

## bilodeau_nist_viscosity\pretrained_models\pretrained_models\nist_dippr_data\test_features.csv
- rows: 6798, cols: 2
- columns: ['MolFrac_1', 'T']
```
   MolFrac_1      T
0        0.0  308.0
1        0.1  308.0
```

## bilodeau_nist_viscosity\pretrained_models\pretrained_models\nist_dippr_model\nist_dippr_model\args.json
- json object, keys: ['activation', 'adding_h', 'aggregation', 'aggregation_norm', 'atom_descriptor_scaling', 'atom_descriptors', 'atom_descriptors_path', 'atom_descriptors_size', 'atom_features_size', 'atom_messages', 'batch_size', 'bias', 'bias_solvent', 'bond_feature_scaling', 'bond_features_path', 'bond_features_size', 'cache_cutoff', 'checkpoint_dir', 'checkpoint_frzn', 'checkpoint_path', 'checkpoint_paths', 'class_balance', 'config_path', 'crossval_index_dir', 'crossval_index_file']

## bilodeau_nist_viscosity\pretrained_models\pretrained_models\nist_dippr_model\nist_dippr_model\fold_0\test_scores.json
- json object, keys: ['rmse']

## bilodeau_nist_viscosity\pretrained_models\pretrained_models\nist_dippr_model\nist_dippr_model\fold_1\test_scores.json
- json object, keys: ['rmse']

## bilodeau_nist_viscosity\pretrained_models\pretrained_models\nist_dippr_model\nist_dippr_model\fold_10\test_scores.json
- json object, keys: ['rmse']

## bilodeau_nist_viscosity\pretrained_models\pretrained_models\nist_dippr_model\nist_dippr_model\fold_11\test_scores.json
- json object, keys: ['rmse']

## bilodeau_nist_viscosity\pretrained_models\pretrained_models\nist_dippr_model\nist_dippr_model\fold_12\test_scores.json
- json object, keys: ['rmse']

## bilodeau_nist_viscosity\pretrained_models\pretrained_models\nist_dippr_model\nist_dippr_model\fold_13\test_scores.json
- json object, keys: ['rmse']

## bilodeau_nist_viscosity\pretrained_models\pretrained_models\nist_dippr_model\nist_dippr_model\fold_14\test_scores.json
- json object, keys: ['rmse']

## bilodeau_nist_viscosity\pretrained_models\pretrained_models\nist_dippr_model\nist_dippr_model\fold_15\test_scores.json
- json object, keys: ['rmse']

## bilodeau_nist_viscosity\pretrained_models\pretrained_models\nist_dippr_model\nist_dippr_model\fold_16\test_scores.json
- json object, keys: ['rmse']

## bilodeau_nist_viscosity\pretrained_models\pretrained_models\nist_dippr_model\nist_dippr_model\fold_17\test_scores.json
- json object, keys: ['rmse']

## bilodeau_nist_viscosity\pretrained_models\pretrained_models\nist_dippr_model\nist_dippr_model\fold_18\test_scores.json
- json object, keys: ['rmse']

## bilodeau_nist_viscosity\pretrained_models\pretrained_models\nist_dippr_model\nist_dippr_model\fold_19\test_scores.json
- json object, keys: ['rmse']

## bilodeau_nist_viscosity\pretrained_models\pretrained_models\nist_dippr_model\nist_dippr_model\fold_2\test_scores.json
- json object, keys: ['rmse']

## bilodeau_nist_viscosity\pretrained_models\pretrained_models\nist_dippr_model\nist_dippr_model\fold_20\test_scores.json
- json object, keys: ['rmse']

## bilodeau_nist_viscosity\pretrained_models\pretrained_models\nist_dippr_model\nist_dippr_model\fold_21\test_scores.json
- json object, keys: ['rmse']

## bilodeau_nist_viscosity\pretrained_models\pretrained_models\nist_dippr_model\nist_dippr_model\fold_22\test_scores.json
- json object, keys: ['rmse']

## bilodeau_nist_viscosity\pretrained_models\pretrained_models\nist_dippr_model\nist_dippr_model\fold_23\test_scores.json
- json object, keys: ['rmse']

## bilodeau_nist_viscosity\pretrained_models\pretrained_models\nist_dippr_model\nist_dippr_model\fold_24\test_scores.json
- json object, keys: ['rmse']

## bilodeau_nist_viscosity\pretrained_models\pretrained_models\nist_dippr_model\nist_dippr_model\fold_3\test_scores.json
- json object, keys: ['rmse']

## bilodeau_nist_viscosity\pretrained_models\pretrained_models\nist_dippr_model\nist_dippr_model\fold_4\test_scores.json
- json object, keys: ['rmse']

## bilodeau_nist_viscosity\pretrained_models\pretrained_models\nist_dippr_model\nist_dippr_model\fold_5\test_scores.json
- json object, keys: ['rmse']

## bilodeau_nist_viscosity\pretrained_models\pretrained_models\nist_dippr_model\nist_dippr_model\fold_6\test_scores.json
- json object, keys: ['rmse']

## bilodeau_nist_viscosity\pretrained_models\pretrained_models\nist_dippr_model\nist_dippr_model\fold_7\test_scores.json
- json object, keys: ['rmse']

## bilodeau_nist_viscosity\pretrained_models\pretrained_models\nist_dippr_model\nist_dippr_model\fold_8\test_scores.json
- json object, keys: ['rmse']

## bilodeau_nist_viscosity\pretrained_models\pretrained_models\nist_dippr_model\nist_dippr_model\fold_9\test_scores.json
- json object, keys: ['rmse']

## bilodeau_nist_viscosity\pretrained_models\pretrained_models\nist_dippr_model\nist_dippr_model\test_scores.csv
- rows: 1, cols: 28
- columns: ['Task', 'Mean rmse', 'Standard deviation rmse', 'Fold 0 rmse', 'Fold 1 rmse', 'Fold 2 rmse', 'Fold 3 rmse', 'Fold 4 rmse', 'Fold 5 rmse', 'Fold 6 rmse', 'Fold 7 rmse', 'Fold 8 rmse', 'Fold 9 rmse', 'Fold 10 rmse', 'Fold 11 rmse', 'Fold 12 rmse', 'Fold 13 rmse', 'Fold 14 rmse', 'Fold 15 rmse', 'Fold 16 rmse', 'Fold 17 rmse', 'Fold 18 rmse', 'Fold 19 rmse', 'Fold 20 rmse', 'Fold 21 rmse', 'Fold 22 rmse', 'Fold 23 rmse', 'Fold 24 rmse']
```
   Task  Mean rmse  Standard deviation rmse  Fold 0 rmse  Fold 1 rmse  Fold 2 rmse  Fold 3 rmse  Fold 4 rmse  Fold 5 rmse  Fold 6 rmse  Fold 7 rmse  Fold 8 rmse  Fold 9 rmse  Fold 10 rmse  Fold 11 rmse  Fold 12 rmse  Fold 13 rmse  Fold 14 rmse  Fold 15 rmse  Fold 16 rmse  Fold 17 rmse  Fold 18 rmse  Fold 19 rmse  Fold 20 rmse  Fold 21 rmse  Fold 22 rmse  Fold 23 rmse  Fold 24 rmse
0  logV   0.054429                 0.012041     0.048616     0.057584     0.052287     0.054931     0.051474     0.055883     0.046056     0.053236     0.049812     0.048021      0.047176      0.080338      0.044756      0.038338      0.057898      0.053493      0.095038      0.060827      0.054651      0.044405      0.070368      0.043364      0.047912      0.044323      0.059928
```

## bilodeau_nist_viscosity\pretrained_models\pretrained_models\nist_dippr_source\logV_bp_mp.csv
- rows: 4617, cols: 4
- columns: ['SMILES', 'logV', 'BP', 'MP']
```
       SMILES      logV    BP  MP
0       CCCCC -0.645721  36.0 NaN
1  CC(C)(C)CC -0.464308   NaN NaN
```

## leenhouts_benchmark\croissant_metadata\datasets\flashpoint\metadata.croissant.json
- json object, keys: ['@context', '@type', '@id', 'conformsTo', 'name', 'description', 'keywords', 'distribution', 'recordSet', 'prov:wasGeneratedBy', 'identifier', 'url', 'citeAs', 'version', 'sameAs', 'license', 'usageInfo', 'rai:dataLimitations', 'rai:dataBiases', 'rai:personalSensitiveInformation', 'rai:dataUseCases', 'rai:dataSocialImpact', 'rai:hasSyntheticData']

## leenhouts_benchmark\croissant_metadata\datasets\fuel_ignition_numbers\metadata.croissant.json
- json object, keys: ['@context', '@type', '@id', 'conformsTo', 'name', 'description', 'keywords', 'distribution', 'recordSet', 'prov:wasGeneratedBy', 'identifier', 'url', 'citeAs', 'version', 'sameAs', 'license', 'usageInfo', 'rai:dataLimitations', 'rai:dataBiases', 'rai:personalSensitiveInformation', 'rai:dataUseCases', 'rai:dataSocialImpact', 'rai:hasSyntheticData']

## leenhouts_benchmark\croissant_metadata\datasets\solubility\metadata.croissant.json
- json object, keys: ['@context', '@type', '@id', 'conformsTo', 'name', 'description', 'keywords', 'distribution', 'recordSet', 'prov:wasGeneratedBy', 'identifier', 'url', 'citeAs', 'version', 'sameAs', 'license', 'usageInfo', 'rai:dataLimitations', 'rai:dataBiases', 'rai:personalSensitiveInformation', 'rai:dataUseCases', 'rai:dataSocialImpact', 'rai:hasSyntheticData']

## leenhouts_benchmark\croissant_metadata\datasets\solvation_free_energy\metadata.croissant.json
- json object, keys: ['@context', '@type', '@id', 'conformsTo', 'name', 'description', 'keywords', 'distribution', 'recordSet', 'prov:wasGeneratedBy', 'identifier', 'url', 'citeAs', 'version', 'sameAs', 'license', 'usageInfo', 'rai:dataLimitations', 'rai:dataBiases', 'rai:personalSensitiveInformation', 'rai:dataUseCases', 'rai:dataSocialImpact', 'rai:hasSyntheticData']

## leenhouts_benchmark\croissant_metadata\datasets\vap_enthalpy\metadata.croissant.json
- json object, keys: ['@context', '@type', '@id', 'conformsTo', 'name', 'description', 'keywords', 'distribution', 'recordSet', 'prov:wasGeneratedBy', 'identifier', 'url', 'citeAs', 'version', 'sameAs', 'license', 'usageInfo', 'rai:dataLimitations', 'rai:dataBiases', 'rai:personalSensitiveInformation', 'rai:dataUseCases', 'rai:dataSocialImpact', 'rai:hasSyntheticData']

## leenhouts_benchmark\croissant_metadata\datasets\viscosity\metadata.croissant.json
- json object, keys: ['@context', '@type', '@id', 'conformsTo', 'name', 'description', 'keywords', 'distribution', 'recordSet', 'prov:wasGeneratedBy', 'identifier', 'url', 'citeAs', 'version', 'sameAs', 'license', 'usageInfo', 'rai:dataLimitations', 'rai:dataBiases', 'rai:personalSensitiveInformation', 'rai:dataUseCases', 'rai:dataSocialImpact', 'rai:hasSyntheticData']

## leenhouts_benchmark\datasets\datasets\flashpoint\metadata.croissant.json
- json object, keys: ['@context', '@type', '@id', 'conformsTo', 'name', 'description', 'keywords', 'distribution', 'recordSet', 'prov:wasGeneratedBy', 'identifier', 'url', 'citeAs', 'version', 'sameAs', 'license', 'usageInfo', 'rai:dataLimitations', 'rai:dataBiases', 'rai:personalSensitiveInformation', 'rai:dataUseCases', 'rai:dataSocialImpact', 'rai:hasSyntheticData']

## leenhouts_benchmark\datasets\datasets\flashpoint\source_provenance.json
- json object, keys: ['manifest_version', 'dataset_id', 'dataset_name', 'standardization_script', 'usage_note', 'source_license_summary', 'sources']

## leenhouts_benchmark\datasets\datasets\fuel_ignition_numbers\DatasetsFuelProperties.xlsx
- rows: 50000, cols: 9
- sheets: ['Viscosity synthetic', 'Viscosity_training', 'Viscosity_test', 'Flashpoint synthetic', 'Flashpoint_training', 'Flashpoint_test', 'DCN synthetic', 'DCN_training', 'DCN_test']
- columns: ['Unnamed: 0', 'fuel1 inchi', 'fuel2 inchi', 'fuel3 inchi', 'fuel4 inchi', 'molar fraction fuel 1', 'molar fraction fuel 2', 'molar fraction fuel 3', 'Synthetic value']
```
   Unnamed: 0                          fuel1 inchi                          fuel2 inchi                          fuel3 inchi                          fuel4 inchi  molar fraction fuel 1  molar fraction fuel 2  molar fraction fuel 3  Synthetic value
0           0  InChI=1S/C6H14O/c1-6(2,3)4-5-7/h...  InChI=1S/C8H16O/c1-2-3-5-8-6-4-7...                                  NaN                                  NaN               0.487805                    NaN                    NaN             2.33
1           1  InChI=1S/C9H20/c1-5-9(6-2)7-8(3)...  InChI=1S/C5H12O/c1-4(2)5(3)6/h4-...  InChI=1S/C10H12/c1-3-9-5-7-10(4-...  InChI=1S/C5H10O2/c1-3-5(6)7-4-2/...               0.564706               0.070588               0.070588             0.72
```

## leenhouts_benchmark\datasets\datasets\fuel_ignition_numbers\metadata.croissant.json
- json object, keys: ['@context', '@type', '@id', 'conformsTo', 'name', 'description', 'keywords', 'distribution', 'recordSet', 'prov:wasGeneratedBy', 'identifier', 'url', 'citeAs', 'version', 'sameAs', 'license', 'usageInfo', 'rai:dataLimitations', 'rai:dataBiases', 'rai:personalSensitiveInformation', 'rai:dataUseCases', 'rai:dataSocialImpact', 'rai:hasSyntheticData']

## leenhouts_benchmark\datasets\datasets\fuel_ignition_numbers\source_provenance.json
- json object, keys: ['manifest_version', 'dataset_id', 'dataset_name', 'standardization_script', 'usage_note', 'source_license_summary', 'sources']

## leenhouts_benchmark\datasets\datasets\solubility\metadata.croissant.json
- json object, keys: ['@context', '@type', '@id', 'conformsTo', 'name', 'description', 'keywords', 'distribution', 'recordSet', 'prov:wasGeneratedBy', 'identifier', 'url', 'citeAs', 'version', 'sameAs', 'license', 'usageInfo', 'rai:dataLimitations', 'rai:dataBiases', 'rai:personalSensitiveInformation', 'rai:dataUseCases', 'rai:dataSocialImpact', 'rai:hasSyntheticData']

## leenhouts_benchmark\datasets\datasets\solubility\source_provenance.json
- json object, keys: ['manifest_version', 'dataset_id', 'dataset_name', 'standardization_script', 'usage_note', 'source_license_summary', 'sources']

## leenhouts_benchmark\datasets\datasets\solvation_free_energy\metadata.croissant.json
- json object, keys: ['@context', '@type', '@id', 'conformsTo', 'name', 'description', 'keywords', 'distribution', 'recordSet', 'prov:wasGeneratedBy', 'identifier', 'url', 'citeAs', 'version', 'sameAs', 'license', 'usageInfo', 'rai:dataLimitations', 'rai:dataBiases', 'rai:personalSensitiveInformation', 'rai:dataUseCases', 'rai:dataSocialImpact', 'rai:hasSyntheticData']

## leenhouts_benchmark\datasets\datasets\solvation_free_energy\source_provenance.json
- json object, keys: ['manifest_version', 'dataset_id', 'dataset_name', 'standardization_script', 'usage_note', 'source_license_summary', 'sources']

## leenhouts_benchmark\datasets\datasets\vap_enthalpy\metadata.croissant.json
- json object, keys: ['@context', '@type', '@id', 'conformsTo', 'name', 'description', 'keywords', 'distribution', 'recordSet', 'prov:wasGeneratedBy', 'identifier', 'url', 'citeAs', 'version', 'sameAs', 'license', 'usageInfo', 'rai:dataLimitations', 'rai:dataBiases', 'rai:personalSensitiveInformation', 'rai:dataUseCases', 'rai:dataSocialImpact', 'rai:hasSyntheticData']

## leenhouts_benchmark\datasets\datasets\vap_enthalpy\source_provenance.json
- json object, keys: ['manifest_version', 'dataset_id', 'dataset_name', 'standardization_script', 'usage_note', 'source_license_summary', 'sources']

## leenhouts_benchmark\datasets\datasets\viscosity\DatasetsFuelProperties.xlsx
- rows: 50000, cols: 9
- sheets: ['Viscosity synthetic', 'Viscosity_training', 'Viscosity_test', 'Flashpoint synthetic', 'Flashpoint_training', 'Flashpoint_test', 'DCN synthetic', 'DCN_training', 'DCN_test']
- columns: ['Unnamed: 0', 'fuel1 inchi', 'fuel2 inchi', 'fuel3 inchi', 'fuel4 inchi', 'molar fraction fuel 1', 'molar fraction fuel 2', 'molar fraction fuel 3', 'Synthetic value']
```
   Unnamed: 0                          fuel1 inchi                          fuel2 inchi                          fuel3 inchi                          fuel4 inchi  molar fraction fuel 1  molar fraction fuel 2  molar fraction fuel 3  Synthetic value
0           0  InChI=1S/C6H14O/c1-6(2,3)4-5-7/h...  InChI=1S/C8H16O/c1-2-3-5-8-6-4-7...                                  NaN                                  NaN               0.487805                    NaN                    NaN             2.33
1           1  InChI=1S/C9H20/c1-5-9(6-2)7-8(3)...  InChI=1S/C5H12O/c1-4(2)5(3)6/h4-...  InChI=1S/C10H12/c1-3-9-5-7-10(4-...  InChI=1S/C5H10O2/c1-3-5(6)7-4-2/...               0.564706               0.070588               0.070588             0.72
```

## leenhouts_benchmark\datasets\datasets\viscosity\metadata.croissant.json
- json object, keys: ['@context', '@type', '@id', 'conformsTo', 'name', 'description', 'keywords', 'distribution', 'recordSet', 'prov:wasGeneratedBy', 'identifier', 'url', 'citeAs', 'version', 'sameAs', 'license', 'usageInfo', 'rai:dataLimitations', 'rai:dataBiases', 'rai:personalSensitiveInformation', 'rai:dataUseCases', 'rai:dataSocialImpact', 'rai:hasSyntheticData']

## leenhouts_benchmark\datasets\datasets\viscosity\PureFuels.xlsx
- rows: 263, cols: 3
- sheets: ['Viscosity', 'Flashpoint', 'DCN']
- columns: ['Unnamed: 0', 'InChI', 'Viscosity [mPa*s]']
```
   Unnamed: 0                            InChI  Viscosity [mPa*s]
0           0        InChI=1S/C2H6/c1-2/h1-2H3             0.0094
1           1  InChI=1S/C3H8/c1-3-2/h3H2,1-2H3             0.0083
```

## leenhouts_benchmark\datasets\datasets\viscosity\source_provenance.json
- json object, keys: ['manifest_version', 'dataset_id', 'dataset_name', 'standardization_script', 'usage_note', 'source_license_summary', 'sources']

## leenhouts_benchmark\datasets\datasets\solubility\rejected_data\solubility_mix_exp_rejected.csv
- rows: 23474, cols: 11
- columns: ['dataset', 'row_index', 'reason', 'raw_solute_identifier', 'raw_solvent_identifier_0', 'raw_solvent_identifier_1', 'raw_fraction_0', 'raw_fraction_type', 'raw_temperature_K', 'raw_solubility_mole_fraction', 'raw_solubility_g_per_100g']
```
        dataset  row_index                               reason                raw_solute_identifier raw_solvent_identifier_0 raw_solvent_identifier_1  raw_fraction_0 raw_fraction_type  raw_temperature_K  raw_solubility_mole_fraction  raw_solubility_g_per_100g
0  MixtureSolDB          0  invalid_solute_identifier:contai...  CCN(C)C(=O)Oc1cccc([C@H](C)N(C)C...                     CC#N                        O             0.0              mole             278.15                        0.0872                 212.339615
1  MixtureSolDB          1  invalid_solute_identifier:contai...  CCN(C)C(=O)Oc1cccc([C@H](C)N(C)C...                     CC#N                        O             0.0              mole             283.15                        0.0983                 242.315737
```

## leenhouts_benchmark\datasets\datasets\solubility\rejected_data\solubility_pure_exp_rejected.csv
- rows: 10437, cols: 8
- columns: ['dataset', 'row_index', 'reason', 'raw_solute_identifier', 'raw_solvent_identifier_0', 'raw_temperature_K', 'raw_solubility_mole_fraction', 'raw_solubility_mol_L']
```
        dataset  row_index                               reason                raw_solute_identifier raw_solvent_identifier_0  raw_temperature_K  raw_solubility_mole_fraction  raw_solubility_mol_L
0  BigSolDBv2_1         99  invalid_solute_identifier:contai...  COc1cc2c(cc1OC)C(=O)C(CC1CCN(Cc3...                      CCO             278.15                      0.000291              0.005071
1  BigSolDBv2_1        100  invalid_solute_identifier:contai...  COc1cc2c(cc1OC)C(=O)C(CC1CCN(Cc3...                      CCO             283.15                      0.000379              0.006564
```

## leenhouts_benchmark\datasets\datasets\solvation_free_energy\rejected_data\gsolv_pure_comp_rejected.csv
- rows: 2734, cols: 8
- columns: ['dataset', 'row_index', 'reason', 'raw_inchi_solute', 'raw_inchi_solvent1', 'raw_frac_solvent1', 'raw_inchi_solvent2', 'raw_gsolv_kcal_per_mol']
```
        dataset  row_index                               reason                     raw_inchi_solute                   raw_inchi_solvent1  raw_frac_solvent1                   raw_inchi_solvent2  raw_gsolv_kcal_per_mol
0  MixSolvGH-QM        190  invalid_solute_identifier:contai...  InChI=1/C6H8O4Se/c7-5(8)3-1-2-4(...  InChI=1/C2H4O2/c1-2(3)4/h1H3,(H,...                0.8  InChI=1/C8H18/c1-7(2)6-8(3,4)5/h...              -15.968391
1  MixSolvGH-QM        412  invalid_solute_identifier:contai...  InChI=1/C12H10Se2/c1-3-7-11(8-4-...        InChI=1/C3H6O/c1-3(2)4/h1-2H3                0.5  InChI=1/C4H8O/c1-3-4(2)5/h3H2,1-2H3              -11.965715
```


# Splits (summary)

- `leenhouts_benchmark\splits\splits\enthalpy\enthalpy_vap_mix_comp`: 1 files, e.g. metadata.json
- `leenhouts_benchmark\splits\splits\enthalpy\enthalpy_vap_mix_comp\split_definitions\mixture\cross_validation_5fold`: 5 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\enthalpy\enthalpy_vap_mix_comp\split_definitions\molecule\cross_validation_5fold`: 5 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\enthalpy\enthalpy_vap_mix_comp\split_definitions\pure_to_mixture\cross_validation_5fold`: 5 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\enthalpy\enthalpy_vap_mix_comp\split_definitions\random_rowwise\cross_validation_5fold`: 5 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\flashpoint\flashpoint_mix_exp`: 1 files, e.g. metadata.json
- `leenhouts_benchmark\splits\splits\flashpoint\flashpoint_mix_exp\split_definitions\mixture\cross_validation_5fold`: 5 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\flashpoint\flashpoint_mix_exp\split_definitions\molecule\cross_validation_5fold`: 5 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\flashpoint\flashpoint_mix_exp\split_definitions\pure_to_mixture\cross_validation_5fold`: 5 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\flashpoint\flashpoint_mix_exp\split_definitions\random_rowwise\cross_validation_5fold`: 5 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\fuel_ignition_numbers\dcn_mix_exp`: 1 files, e.g. metadata.json
- `leenhouts_benchmark\splits\splits\fuel_ignition_numbers\dcn_mix_exp\review_rows\mixture_combination`: 5 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\fuel_ignition_numbers\dcn_mix_exp\review_rows\molecule_type`: 5 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\fuel_ignition_numbers\dcn_mix_exp\review_rows\pure_to_mixture`: 5 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\fuel_ignition_numbers\dcn_mix_exp\split_definitions\mixture\cross_validation_5fold`: 5 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\fuel_ignition_numbers\dcn_mix_exp\split_definitions\random_rowwise\cross_validation_5fold`: 5 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\fuel_ignition_numbers\mon_mix_exp`: 1 files, e.g. metadata.json
- `leenhouts_benchmark\splits\splits\fuel_ignition_numbers\mon_mix_exp\split_definitions\mixture\cross_validation_5fold`: 5 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\fuel_ignition_numbers\mon_mix_exp\split_definitions\random_rowwise\cross_validation_5fold`: 5 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\solubility\solubility_mix_exp`: 1 files, e.g. metadata.json
- `leenhouts_benchmark\splits\splits\solubility\solubility_mix_exp\id_maps`: 2 files, e.g. mix_id_map.csv
- `leenhouts_benchmark\splits\splits\solubility\solubility_mix_exp\review_rows\mixture_combination`: 5 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\solubility\solubility_mix_exp\review_rows\mixture_context_temperature`: 5 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\solubility\solubility_mix_exp\review_rows\molecule_type`: 5 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\solubility\solubility_mix_exp\review_rows\pure_to_mixture`: 5 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\solubility\solubility_mix_exp\split_definitions\mixture\cross_validation_5fold`: 5 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\solubility\solubility_mix_exp\split_definitions\mixture_temperature\cross_validation_5fold`: 10 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\solubility\solubility_mix_exp\split_definitions\molecule\cross_validation_5fold`: 5 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\solubility\solubility_mix_exp\split_definitions\pure_to_mixture\cross_validation_5fold`: 5 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\solubility\solubility_mix_exp\split_definitions\random_rowwise\cross_validation_5fold`: 5 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\solvation_free_energy\gsolv_mix_comp`: 3 files, e.g. metadata.json
- `leenhouts_benchmark\splits\splits\solvation_free_energy\gsolv_mix_comp\id_maps`: 2 files, e.g. mix_id_map.csv
- `leenhouts_benchmark\splits\splits\solvation_free_energy\gsolv_mix_comp\split_definitions\mixture\cross_validation_5fold`: 5 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\solvation_free_energy\gsolv_mix_comp\split_definitions\mixture\cross_validation_5fold_train100k`: 2 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\solvation_free_energy\gsolv_mix_comp\split_definitions\molecule\cross_validation_5fold`: 5 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\solvation_free_energy\gsolv_mix_comp\split_definitions\pure_to_mixture\cross_validation_5fold`: 5 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\solvation_free_energy\gsolv_mix_comp\split_definitions\random_rowwise\cross_validation_5fold`: 5 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\viscosity\viscosity_mix_exp`: 1 files, e.g. metadata.json
- `leenhouts_benchmark\splits\splits\viscosity\viscosity_mix_exp\review_rows\mixture_combination`: 5 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\viscosity\viscosity_mix_exp\review_rows\mixture_context_temperature`: 5 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\viscosity\viscosity_mix_exp\review_rows\molecule_type`: 5 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\viscosity\viscosity_mix_exp\review_rows\pure_to_mixture`: 5 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\viscosity\viscosity_mix_exp\split_definitions\mixture\cross_validation_5fold`: 5 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\viscosity\viscosity_mix_exp\split_definitions\mixture_temperature\cross_validation_5fold`: 10 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\viscosity\viscosity_mix_exp\split_definitions\molecule\cross_validation_5fold`: 5 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\viscosity\viscosity_mix_exp\split_definitions\pure_to_mixture\cross_validation_5fold`: 5 files, e.g. fold_00.csv
- `leenhouts_benchmark\splits\splits\viscosity\viscosity_mix_exp\split_definitions\random_rowwise\cross_validation_5fold`: 5 files, e.g. fold_00.csv

Example split file schema:
- json object, keys: ['pure_file', 'mix_file', 'holdout_molecule_count', 'holdout_molecules', 'temperature_context_cols', 'mixture_context_temperature_split_excluded', 'mixture_context_temperature_heldout_count', 'mixture_context_temperature_heldout_preview', 'solute_context_cols', 'mixture_context_solute_split_excluded', 'mixture_context_solute_heldout_count', 'mixture_context_solute_heldout_preview', 'cross_validation_10fold_per_split_dirs', 'cross_validation_10fold_folds', 'cross_validation_10fold_ratio', 'cross_validation_5fold_per_split_dirs', 'cross_validation_5fold_folds', 'cross_validation_5fold_ratio', 'cross_validation_5fold_per_split_ratios']


# Other files by extension
{'.md': 1, '.log': 2, '.d-13-10-2': 25, '.pt': 25, '.py': 10}